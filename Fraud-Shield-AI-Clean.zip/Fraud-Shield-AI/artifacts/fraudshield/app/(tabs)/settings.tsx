// Settings — language toggle, theme, voice assistant, about, demo reset.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAppState } from "@/lib/presentation/appState";
import { useI18n, type Locale } from "@/lib/presentation/i18n";
import { useTheme, type ThemeMode } from "@/lib/presentation/theme";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { colors, mode, setMode, isDark } = useTheme();
  const { t, locale, setLocale, speak } = useI18n();
  const { resetDemo } = useAppState();

  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceReply, setVoiceReply] = useState<string | null>(null);

  const onSpeak = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    }
    setVoiceActive(true);
    setVoiceReply(null);
    setTimeout(() => {
      setVoiceReply(speak());
      setVoiceActive(false);
    }, 1300);
  };

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: 120 + insets.bottom,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.title, { color: colors.foreground }]}>
          {t.settings}
        </Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>
          {t.appName}
        </Text>

        {/* Language */}
        <SectionLabel title={t.language} />
        <View
          style={[
            styles.row,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          {(["en", "ur"] as Locale[]).map((l) => {
            const active = locale === l;
            return (
              <Pressable
                key={l}
                onPress={() => setLocale(l)}
                style={[
                  styles.segment,
                  active && { backgroundColor: colors.foreground },
                ]}
              >
                <Text
                  style={[
                    styles.segmentText,
                    {
                      color: active ? colors.background : colors.foreground,
                    },
                  ]}
                >
                  {l === "en" ? "English" : "اردو"}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* Theme */}
        <SectionLabel title={t.theme} />
        <View
          style={[
            styles.row,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          {(["light", "system", "dark"] as ThemeMode[]).map((m) => {
            const active = mode === m;
            return (
              <Pressable
                key={m}
                onPress={() => setMode(m)}
                style={[
                  styles.segment,
                  active && { backgroundColor: colors.foreground },
                ]}
              >
                <Feather
                  name={
                    m === "light" ? "sun" : m === "dark" ? "moon" : "smartphone"
                  }
                  size={14}
                  color={active ? colors.background : colors.foreground}
                />
                <Text
                  style={[
                    styles.segmentText,
                    {
                      color: active ? colors.background : colors.foreground,
                    },
                  ]}
                >
                  {m === "light"
                    ? t.light
                    : m === "dark"
                      ? t.dark
                      : "Auto"}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* Voice */}
        <SectionLabel title={t.voice} />
        <View
          style={[
            styles.voiceCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Pressable onPress={onSpeak} style={styles.micWrap}>
            <MicGlow active={voiceActive} />
            <View
              style={[
                styles.micCore,
                { backgroundColor: colors.accent },
              ]}
            >
              <Feather name="mic" size={26} color="#fff" />
            </View>
          </Pressable>
          <Text style={[styles.voiceLabel, { color: colors.foreground }]}>
            {voiceActive ? t.authenticating : t.speak}
          </Text>
          <Text style={[styles.voiceHint, { color: colors.mutedForeground }]}>
            {t.voiceHint}
          </Text>
          {voiceReply ? (
            <View
              style={[
                styles.bubble,
                {
                  backgroundColor: colors.accent + "15",
                  borderColor: colors.accent + "44",
                },
              ]}
            >
              <Feather name="message-circle" size={14} color={colors.accent} />
              <Text style={[styles.bubbleText, { color: colors.foreground }]}>
                {voiceReply}
              </Text>
            </View>
          ) : null}
        </View>

        {/* About */}
        <SectionLabel title={t.about} />
        <View
          style={[
            styles.aboutCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <View
            style={[
              styles.aboutIcon,
              { backgroundColor: colors.accent + "1F" },
            ]}
          >
            <Feather name="shield" size={22} color={colors.accent} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.aboutTitle, { color: colors.foreground }]}>
              {t.appName}
            </Text>
            <Text style={[styles.aboutBody, { color: colors.mutedForeground }]}>
              {t.aboutBody}
            </Text>
          </View>
        </View>

        {/* Reset demo */}
        <Pressable
          onPress={resetDemo}
          style={({ pressed }) => [
            styles.resetBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Feather name="refresh-ccw" size={16} color={colors.foreground} />
          <Text style={[styles.resetText, { color: colors.foreground }]}>
            Reset demo data
          </Text>
        </Pressable>

        <View style={{ flexDirection: "row", gap: 8, marginTop: 24, alignItems: "center", justifyContent: "center" }}>
          <Switch value={isDark} disabled />
          <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_400Regular", fontSize: 11 }}>
            v1.0.0 · Hackathon Prototype
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

function SectionLabel({ title }: { title: string }) {
  const { colors } = useTheme();
  return (
    <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
      {title}
    </Text>
  );
}

function MicGlow({ active }: { active: boolean }) {
  const { colors } = useTheme();
  const scale = useSharedValue(1);
  useEffect(() => {
    if (active) {
      scale.value = withRepeat(
        withTiming(1.4, { duration: 700, easing: Easing.inOut(Easing.quad) }),
        -1,
        true,
      );
    } else {
      scale.value = 1;
    }
  }, [active, scale]);
  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: active ? 0.8 : 0,
  }));
  return (
    <Animated.View
      style={[
        styles.micGlow,
        { backgroundColor: colors.accent + "55" },
        animStyle,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: 20 },
  title: { fontFamily: "Inter_700Bold", fontSize: 26, letterSpacing: -0.5 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 4 },
  sectionLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    letterSpacing: 0.8,
    textTransform: "uppercase",
    marginTop: 28,
    marginBottom: 10,
  },
  row: {
    flexDirection: "row",
    padding: 4,
    borderWidth: 1,
  },
  segment: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  segmentText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  voiceCard: {
    padding: 20,
    alignItems: "center",
    borderWidth: 1,
    gap: 8,
  },
  micWrap: {
    width: 90,
    height: 90,
    alignItems: "center",
    justifyContent: "center",
  },
  micGlow: {
    position: "absolute",
    width: 90,
    height: 90,
    borderRadius: 45,
  },
  micCore: {
    width: 70,
    height: 70,
    borderRadius: 35,
    alignItems: "center",
    justifyContent: "center",
  },
  voiceLabel: { fontFamily: "Inter_600SemiBold", fontSize: 14, marginTop: 8 },
  voiceHint: { fontFamily: "Inter_400Regular", fontSize: 12 },
  bubble: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginTop: 10,
    width: "100%",
  },
  bubbleText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13 },
  aboutCard: {
    flexDirection: "row",
    gap: 12,
    padding: 16,
    borderWidth: 1,
  },
  aboutIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  aboutTitle: { fontFamily: "Inter_700Bold", fontSize: 15 },
  aboutBody: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 4,
    lineHeight: 18,
  },
  resetBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 14,
    borderWidth: 1,
    marginTop: 20,
  },
  resetText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
});
