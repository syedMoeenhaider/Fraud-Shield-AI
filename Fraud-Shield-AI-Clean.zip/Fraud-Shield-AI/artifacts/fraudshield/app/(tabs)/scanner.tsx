// SMS Scanner — lists messages with heuristic + AI verdicts.
// New messages added via the composer are auto-analyzed immediately
// without requiring a tap (autoAnalyze prop). URLs inside messages
// are extracted and flagged separately.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { GradientButton } from "@/components/GradientButton";
import { MessageItem } from "@/components/MessageItem";
import { analyzeMessage } from "@/lib/domain/analyzers";
import { useAppState } from "@/lib/presentation/appState";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

type Filter = "all" | "danger" | "suspicious" | "safe";

export default function ScannerScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t, locale } = useI18n();
  const { messages, addMessage, removeMessage } = useAppState();

  const [filter, setFilter] = useState<Filter>("all");
  const [refreshing, setRefreshing] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [draftSender, setDraftSender] = useState("");
  const [draftBody, setDraftBody] = useState("");

  // Track the ID of the most-recently added message so we can pass
  // autoAnalyze={true} to it — triggering instant AI + notifications.
  const [newMessageId, setNewMessageId] = useState<string | null>(null);

  const counts = useMemo(() => {
    const c = { all: messages.length, danger: 0, suspicious: 0, safe: 0 };
    for (const m of messages) {
      const v = analyzeMessage(m);
      c[v.risk] += 1;
    }
    return c;
  }, [messages]);

  const filtered = useMemo(() => {
    if (filter === "all") return messages;
    return messages.filter((m) => analyzeMessage(m).risk === filter);
  }, [messages, filter]);

  const onRefresh = () => {
    setRefreshing(true);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    }
    setTimeout(() => setRefreshing(false), 600);
  };

  // Save the pasted message, close the composer, then auto-trigger
  // full AI analysis + URL extraction + notification on the new item.
  const onSubmitDraft = async () => {
    const sender = draftSender.trim() || "Unknown";
    const body = draftBody.trim();
    if (!body) return;

    const newMsg = await addMessage({ sender, body });

    // Mark this message for immediate auto-analysis.
    setNewMessageId(newMsg.id);

    // Reset composer.
    setDraftSender("");
    setDraftBody("");
    setComposerOpen(false);

    if (Platform.OS !== "web") {
      Haptics.notificationAsync(
        Haptics.NotificationFeedbackType.Success,
      ).catch(() => {});
    }

    // Clear the auto-analyze flag after a short delay so re-renders
    // don't re-trigger it (analysis is already in-flight).
    setTimeout(() => setNewMessageId(null), 500);
  };

  const onLongPress = (id: string, sender: string) => {
    if (Platform.OS === "web") {
      const ok =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm(`${t.deleteMessage}: ${sender}?`)
          : true;
      if (ok) removeMessage(id);
      return;
    }
    Alert.alert(t.deleteMessage, sender, [
      { text: t.cancel, style: "cancel" },
      {
        text: t.delete,
        style: "destructive",
        onPress: () => removeMessage(id),
      },
    ]);
  };

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: 120 + insets.bottom,
          },
        ]}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* ── Header ── */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>
              {t.smsHeader}
            </Text>
            <Text style={[styles.sub, { color: colors.mutedForeground }]}>
              {t.smsSubtitle}
            </Text>
          </View>
          <View
            style={[
              styles.iconBubble,
              { backgroundColor: colors.accent + "1F" },
            ]}
          >
            <Feather name="shield" size={22} color={colors.accent} />
          </View>
        </View>

        {/* ── Summary chips ── */}
        <View style={styles.summaryRow}>
          <SummaryChip label={t.dangerous} value={counts.danger} color={colors.danger} />
          <SummaryChip label={t.suspicious} value={counts.suspicious} color={colors.warning} />
          <SummaryChip label={t.safe} value={counts.safe} color={colors.success} />
        </View>

        {/* ── Add real message button ── */}
        <View style={{ marginTop: 16 }}>
          <GradientButton
            label={t.addMessage}
            onPress={() => setComposerOpen(true)}
            icon={<Feather name="plus" size={16} color="#fff" />}
          />
        </View>

        {/* ── Auto-scan info bar ── */}
        <View
          style={[
            styles.infoBar,
            {
              backgroundColor: colors.accent + "12",
              borderColor: colors.accent + "40",
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather name="cpu" size={13} color={colors.accent} />
          <Text style={[styles.infoText, { color: colors.accent }]}>
            {locale === "ur"
              ? "نیا پیغام شامل کریں — اے آئی فوراً اسکین کرے گا اور نوٹیفکیشن بھیجے گا"
              : "Add a message → AI scans instantly & sends a notification"}
          </Text>
        </View>

        {/* ── Filter chips ── */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {(["all", "danger", "suspicious", "safe"] as Filter[]).map((f) => {
            const active = filter === f;
            return (
              <Pressable
                key={f}
                onPress={() => setFilter(f)}
                style={[
                  styles.chip,
                  {
                    backgroundColor: active ? colors.foreground : colors.surface,
                    borderColor: active ? colors.foreground : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.chipText,
                    { color: active ? colors.background : colors.foreground },
                  ]}
                >
                  {f === "all"
                    ? `All · ${counts.all}`
                    : f === "danger"
                      ? `${t.dangerous} · ${counts.danger}`
                      : f === "suspicious"
                        ? `${t.suspicious} · ${counts.suspicious}`
                        : `${t.safe} · ${counts.safe}`}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* ── Message list ── */}
        <View style={{ gap: 12, marginTop: 14 }}>
          {filtered.map((m, i) => (
            <Animated.View
              key={m.id}
              entering={FadeInDown.delay(Math.min(i, 6) * 50).duration(320)}
            >
              <Pressable
                onLongPress={() => onLongPress(m.id, m.sender)}
                delayLongPress={500}
              >
                {/* autoAnalyze fires immediately for the newest message */}
                <MessageItem
                  message={m}
                  autoAnalyze={m.id === newMessageId}
                />
              </Pressable>
            </Animated.View>
          ))}

          {filtered.length === 0 ? (
            <View
              style={[
                styles.empty,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Feather name="inbox" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                {t.emptyInbox}
              </Text>
              <Text style={[styles.emptyHint, { color: colors.mutedForeground }]}>
                {t.emptyInboxHint}
              </Text>
            </View>
          ) : (
            <Text style={[styles.longPressHint, { color: colors.mutedForeground }]}>
              {locale === "ur"
                ? "حذف کرنے کے لیے دبائے رکھیں"
                : "Long-press a message to delete"}
            </Text>
          )}
        </View>
      </ScrollView>

      {/* ── Paste SMS composer modal ── */}
      <Modal
        visible={composerOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setComposerOpen(false)}
      >
        <View style={[modalStyles.backdrop, { paddingBottom: insets.bottom }]}>
          <Pressable style={modalStyles.dismiss} onPress={() => setComposerOpen(false)} />
          <View style={[modalStyles.sheet, { backgroundColor: colors.background }]}>
            <View style={modalStyles.handle}>
              <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
            </View>

            <Text style={[modalStyles.title, { color: colors.foreground }]}>
              {t.addMessage}
            </Text>
            <Text style={[modalStyles.helper, { color: colors.mutedForeground }]}>
              {t.pasteMessage}
            </Text>

            {/* Auto-scan feature badge */}
            <View style={[modalStyles.autoBadge, { backgroundColor: colors.accent + "18", borderColor: colors.accent + "44" }]}>
              <Feather name="zap" size={13} color={colors.accent} />
              <Text style={[modalStyles.autoBadgeText, { color: colors.accent }]}>
                {locale === "ur"
                  ? "محفوظ کرتے ہی اے آئی خودبخود اسکین کرے گا"
                  : "AI will auto-scan the moment you save"}
              </Text>
            </View>

            <Text style={[modalStyles.label, { color: colors.mutedForeground }]}>
              {t.senderLabel}
            </Text>
            <TextInput
              value={draftSender}
              onChangeText={setDraftSender}
              placeholder="JAZZCASH"
              placeholderTextColor={colors.mutedForeground}
              style={[
                modalStyles.input,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  color: colors.foreground,
                  borderRadius: colors.radius,
                },
              ]}
              autoCapitalize="characters"
            />

            <Text style={[modalStyles.label, { color: colors.mutedForeground }]}>
              {t.bodyLabel}
            </Text>
            <TextInput
              value={draftBody}
              onChangeText={setDraftBody}
              placeholder="Your account has been temporarily blocked..."
              placeholderTextColor={colors.mutedForeground}
              multiline
              style={[
                modalStyles.input,
                modalStyles.multiline,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  color: colors.foreground,
                  borderRadius: colors.radius,
                },
              ]}
            />

            <View style={{ marginTop: 18 }}>
              <GradientButton
                label={t.saveAndAnalyze}
                onPress={onSubmitDraft}
                disabled={!draftBody.trim()}
                icon={<Feather name="cpu" size={16} color="#fff" />}
              />
            </View>
            <Pressable onPress={() => setComposerOpen(false)} style={modalStyles.cancelBtn}>
              <Text style={[modalStyles.cancelText, { color: colors.mutedForeground }]}>
                {t.cancel}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function SummaryChip({ label, value, color }: { label: string; value: number; color: string }) {
  const { colors } = useTheme();
  return (
    <View
      style={[
        styles.summary,
        { backgroundColor: colors.surface, borderColor: colors.border, borderRadius: colors.radius },
      ]}
    >
      <View style={[styles.dot, { backgroundColor: color }]} />
      <View>
        <Text style={[styles.summaryValue, { color: colors.foreground }]}>{value}</Text>
        <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>{label}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: 20 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  title: { fontFamily: "Inter_700Bold", fontSize: 26, letterSpacing: -0.5 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 4 },
  iconBubble: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  summaryRow: { flexDirection: "row", gap: 10, marginTop: 18 },
  summary: { flex: 1, flexDirection: "row", alignItems: "center", gap: 10, padding: 12, borderWidth: 1 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  summaryValue: { fontFamily: "Inter_700Bold", fontSize: 18 },
  summaryLabel: { fontFamily: "Inter_500Medium", fontSize: 11, marginTop: 1 },
  infoBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 12,
    padding: 12,
    borderWidth: 1,
  },
  infoText: { fontFamily: "Inter_500Medium", fontSize: 12, flex: 1, lineHeight: 16 },
  filterRow: { gap: 8, paddingTop: 18, paddingBottom: 4 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, borderWidth: 1 },
  chipText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  empty: { alignItems: "center", paddingVertical: 40, paddingHorizontal: 20, borderWidth: 1, gap: 8 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  emptyHint: { fontFamily: "Inter_400Regular", fontSize: 12, textAlign: "center" },
  longPressHint: { fontFamily: "Inter_400Regular", fontSize: 11, textAlign: "center", marginTop: 6 },
});

const modalStyles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)", justifyContent: "flex-end" },
  dismiss: { flex: 1 },
  sheet: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 20, borderTopLeftRadius: 28, borderTopRightRadius: 28 },
  handle: { alignItems: "center", marginBottom: 12 },
  title: { fontFamily: "Inter_700Bold", fontSize: 20, marginBottom: 6 },
  helper: { fontFamily: "Inter_400Regular", fontSize: 13, marginBottom: 6 },
  autoBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 6,
  },
  autoBadgeText: { fontFamily: "Inter_600SemiBold", fontSize: 12, flex: 1 },
  label: { fontFamily: "Inter_600SemiBold", fontSize: 11, letterSpacing: 0.7, textTransform: "uppercase", marginTop: 14, marginBottom: 8 },
  input: { borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontFamily: "Inter_500Medium", fontSize: 14 },
  multiline: { minHeight: 100, textAlignVertical: "top" },
  cancelBtn: { alignItems: "center", paddingVertical: 12, marginTop: 4 },
  cancelText: { fontFamily: "Inter_500Medium", fontSize: 13 },
});
