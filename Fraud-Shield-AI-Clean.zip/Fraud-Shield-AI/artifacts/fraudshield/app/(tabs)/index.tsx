// Dashboard — security score, AI alerts, quick actions, recent activity.
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useMemo } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, { FadeInDown, FadeInUp } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AlertBanner } from "@/components/AlertBanner";
import { GlassCard } from "@/components/GlassCard";
import { QuickAction } from "@/components/QuickAction";
import { ScoreRing } from "@/components/ScoreRing";
import { SectionHeader } from "@/components/SectionHeader";
import { TransactionItem } from "@/components/TransactionItem";
import { analyzeTransaction } from "@/lib/domain/analyzers";
import { useAppState } from "@/lib/presentation/appState";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const { colors, isDark } = useTheme();
  const { t, isRtl } = useI18n();
  const { transactions, securityScore, frozen } = useAppState();

  const flagged = useMemo(
    () =>
      transactions
        .map((tx) => ({ tx, v: analyzeTransaction(tx) }))
        .filter((x) => x.v.riskScore >= 70),
    [transactions],
  );

  const protectedLabel =
    securityScore >= 75
      ? t.protected
      : securityScore >= 50
        ? "Caution"
        : "At Risk";

  const webTopInset = Platform.OS === "web" ? 67 : 0;
  const webBottomInset = Platform.OS === "web" ? 0 : 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientEnd]}
        style={[styles.headerGradient, { paddingTop: insets.top + webTopInset + 16 }]}
      >
        <View
          style={[
            styles.headerRow,
            { flexDirection: isRtl ? "row-reverse" : "row" },
          ]}
        >
          <View>
            <Text style={styles.headerEyebrow}>{t.appName}</Text>
            <Text style={styles.headerTitle}>{t.goodMorning}</Text>
            <Text style={styles.headerSub}>{t.tagline}</Text>
          </View>
          <Pressable
            onPress={() => router.push("/freeze")}
            style={({ pressed }) => [
              styles.bell,
              { opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Feather name="bell" size={20} color="#fff" />
            {flagged.length > 0 ? (
              <View
                style={[
                  styles.badgeDot,
                  { backgroundColor: colors.danger },
                ]}
              >
                <Text style={styles.badgeDotText}>{flagged.length}</Text>
              </View>
            ) : null}
          </Pressable>
        </View>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingBottom: 120 + insets.bottom + webBottomInset,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View
          entering={FadeInUp.duration(500)}
          style={[styles.scoreCard, { marginTop: -60 }]}
        >
          <GlassCard padding={22} style={{ alignItems: "center" }}>
            <ScoreRing
              value={securityScore}
              label={t.securityScore}
              sublabel={`${protectedLabel} · ${t.monitoring}`}
            />
            <View style={styles.statsRow}>
              <Stat
                label={t.alerts}
                value={String(flagged.length)}
                color={flagged.length > 0 ? colors.danger : colors.success}
                icon="alert-triangle"
              />
              <View
                style={[styles.divider, { backgroundColor: colors.border }]}
              />
              <Stat
                label={t.recentActivity}
                value={String(transactions.length)}
                color={colors.accent}
                icon="activity"
              />
              <View
                style={[styles.divider, { backgroundColor: colors.border }]}
              />
              <Stat
                label={frozen ? t.accountsFrozen : t.protected}
                value={frozen ? "OFF" : "ON"}
                color={frozen ? colors.danger : colors.success}
                icon={frozen ? "lock" : "shield"}
              />
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View entering={FadeInDown.delay(100).duration(500)}>
          {flagged.length > 0 ? (
            <View style={{ marginTop: 18 }}>
              <AlertBanner
                title={`${flagged.length} ${flagged.length === 1 ? "alert" : "alerts"}`}
                description={flagged[0]?.v.reason ?? ""}
                variant="danger"
              />
            </View>
          ) : (
            <View style={{ marginTop: 18 }}>
              <AlertBanner
                title={t.noAlerts}
                description={t.monitoring}
                variant="success"
              />
            </View>
          )}
        </Animated.View>

        <SectionHeader title={t.quickActions} />

        <Animated.View
          entering={FadeInDown.delay(150).duration(500)}
          style={styles.gridRow}
        >
          <QuickAction
            label={t.scanSms}
            icon="message-square"
            tone="accent"
            onPress={() => router.push("/(tabs)/scanner")}
          />
          <QuickAction
            label={t.checkLink}
            icon="link"
            onPress={() => router.push("/(tabs)/link")}
          />
        </Animated.View>

        <Animated.View
          entering={FadeInDown.delay(220).duration(500)}
          style={[styles.gridRow, { marginTop: 12 }]}
        >
          <QuickAction
            label={t.openVault}
            icon="lock"
            onPress={() => router.push("/(tabs)/vault")}
          />
          <QuickAction
            label={t.emergencyFreeze}
            icon="alert-octagon"
            tone="danger"
            onPress={() => router.push("/freeze")}
          />
        </Animated.View>

        <SectionHeader
          title={t.recentActivity}
          action={{
            label: t.viewAll,
            onPress: () => router.push("/(tabs)/scanner"),
          }}
        />

        <View style={{ gap: 10 }}>
          {transactions.slice(0, 5).map((tx, i) => (
            <Animated.View
              key={tx.id}
              entering={FadeInDown.delay(250 + i * 60).duration(400)}
            >
              <TransactionItem tx={tx} />
            </Animated.View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

function Stat({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: string;
  color: string;
  icon: keyof typeof Feather.glyphMap;
}) {
  const { colors } = useTheme();
  return (
    <View style={styles.stat}>
      <Feather name={icon} size={14} color={color} />
      <Text style={[styles.statValue, { color: colors.foreground }]}>
        {value}
      </Text>
      <Text
        style={[styles.statLabel, { color: colors.mutedForeground }]}
        numberOfLines={1}
      >
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  headerGradient: {
    paddingHorizontal: 20,
    paddingBottom: 90,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerEyebrow: {
    color: "rgba(255,255,255,0.6)",
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    letterSpacing: 1.4,
    textTransform: "uppercase",
  },
  headerTitle: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    marginTop: 4,
    letterSpacing: -0.6,
  },
  headerSub: {
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    marginTop: 4,
  },
  bell: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
  },
  badgeDot: {
    position: "absolute",
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeDotText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 10,
  },
  scroll: { paddingHorizontal: 20 },
  scoreCard: {},
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 22,
    gap: 6,
  },
  stat: { alignItems: "center", flex: 1, gap: 4 },
  statValue: { fontFamily: "Inter_700Bold", fontSize: 16 },
  statLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 10,
    textAlign: "center",
  },
  divider: { width: 1, height: 38 },
  gridRow: { flexDirection: "row", gap: 12 },
});
