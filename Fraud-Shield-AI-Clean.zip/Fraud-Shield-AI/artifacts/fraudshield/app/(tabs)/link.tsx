// Link Safety Checker — runs both a local heuristic and a live AI analysis.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useRef, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeIn, FadeInUp } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AiVerdictCard } from "@/components/AiVerdictCard";
import { GradientButton } from "@/components/GradientButton";
import { analyzeWithAi, type AiVerdict } from "@/lib/data/aiClient";
import { SAMPLE_LINKS } from "@/lib/data/mockData";
import { checkLink, type LinkVerdict } from "@/lib/domain/analyzers";
import { useAppState } from "@/lib/presentation/appState";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

export default function LinkScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t, locale } = useI18n();
  const { registerRiskyClick } = useAppState();

  const [url, setUrl] = useState("");
  const [verdict, setVerdict] = useState<LinkVerdict | null>(null);
  const [aiVerdict, setAiVerdict] = useState<AiVerdict | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const onAnalyze = async (target?: string) => {
    const value = (target ?? url).trim();
    if (!value) return;

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setAnalyzing(true);
    setAiError(null);
    setAiVerdict(null);
    if (Platform.OS !== "web") {
      Haptics.selectionAsync().catch(() => {});
    }

    // Local heuristic — instant.
    const v = checkLink(value);
    setVerdict(v);
    setUrl(value);
    if (v.status !== "safe") registerRiskyClick();
    setAnalyzing(false);

    // Live AI analysis — async.
    setAiLoading(true);
    try {
      const ai = await analyzeWithAi({
        kind: "link",
        content: value,
        locale,
        signal: controller.signal,
      });
      if (controller.signal.aborted) return;
      setAiVerdict(ai);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(
          ai.verdict === "safe"
            ? Haptics.NotificationFeedbackType.Success
            : Haptics.NotificationFeedbackType.Warning,
        ).catch(() => {});
      }
    } catch (err) {
      if (controller.signal.aborted) return;
      const msg =
        err instanceof Error ? err.message : "AI analysis failed";
      setAiError(msg);
    } finally {
      if (!controller.signal.aborted) setAiLoading(false);
    }
  };

  const accent =
    verdict?.status === "danger"
      ? colors.danger
      : verdict?.status === "warning"
        ? colors.warning
        : colors.success;

  const verdictLabel =
    verdict?.status === "danger"
      ? t.dangerous
      : verdict?.status === "warning"
        ? t.suspicious
        : t.safe;

  const verdictIcon =
    verdict?.status === "danger"
      ? "alert-octagon"
      : verdict?.status === "warning"
        ? "alert-triangle"
        : "shield";

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: 120 + insets.bottom,
          },
        ]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>
              {t.linkHeader}
            </Text>
            <Text style={[styles.sub, { color: colors.mutedForeground }]}>
              {t.linkSubtitle}
            </Text>
          </View>
          <View
            style={[
              styles.iconBubble,
              { backgroundColor: colors.accent + "1F" },
            ]}
          >
            <Feather name="link" size={22} color={colors.accent} />
          </View>
        </View>

        <View
          style={[
            styles.inputCard,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather name="search" size={18} color={colors.mutedForeground} />
          <TextInput
            value={url}
            onChangeText={setUrl}
            placeholder={t.enterUrl}
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground }]}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="go"
            onSubmitEditing={() => onAnalyze()}
          />
          {url ? (
            <Pressable onPress={() => setUrl("")}>
              <Feather name="x" size={18} color={colors.mutedForeground} />
            </Pressable>
          ) : null}
        </View>

        <View style={{ marginTop: 14 }}>
          <GradientButton
            label={analyzing ? `${t.analyze}…` : t.analyze}
            onPress={() => onAnalyze()}
            disabled={analyzing || !url.trim()}
            icon={<Feather name="cpu" size={16} color="#fff" />}
          />
        </View>

        <Text style={[styles.tryLabel, { color: colors.mutedForeground }]}>
          {t.trySample}
        </Text>
        <View style={styles.sampleRow}>
          {SAMPLE_LINKS.map((s) => (
            <Pressable
              key={s.url}
              onPress={() => onAnalyze(s.url)}
              style={[
                styles.sampleChip,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                },
              ]}
            >
              <Text
                style={[styles.sampleText, { color: colors.foreground }]}
                numberOfLines={1}
              >
                {s.url.replace(/^https?:\/\//, "")}
              </Text>
              <Text
                style={[styles.sampleHint, { color: colors.mutedForeground }]}
              >
                {s.description}
              </Text>
            </Pressable>
          ))}
        </View>

        {verdict ? (
          <Animated.View
            key={url + verdict.score}
            entering={FadeInUp.duration(450)}
            style={{ marginTop: 24 }}
          >
            <Text style={[styles.sectionTag, { color: colors.mutedForeground }]}>
              {locale === "ur" ? "تیز رفتار اسکین" : "Instant heuristic scan"}
            </Text>
            <LinearGradient
              colors={[accent, accent + "BB"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={[
                styles.verdictCard,
                { borderRadius: colors.radius, marginTop: 8 },
              ]}
            >
              <View style={styles.verdictHeader}>
                <Feather name={verdictIcon} size={28} color="#fff" />
                <View style={{ flex: 1 }}>
                  <Text style={styles.verdictLabel}>{t.result}</Text>
                  <Text style={styles.verdictTitle}>{verdictLabel}</Text>
                </View>
                <View style={styles.scorePill}>
                  <Text style={styles.scoreValue}>{verdict.score}</Text>
                  <Text style={styles.scoreLabel}>{t.riskScore}</Text>
                </View>
              </View>
              <Text style={styles.verdictUrl} numberOfLines={2}>
                {url}
              </Text>
            </LinearGradient>

            <View style={{ gap: 10, marginTop: 14 }}>
              {verdict.reasons.map((r, i) => (
                <Animated.View
                  key={i}
                  entering={FadeIn.delay(i * 80)}
                  style={[
                    styles.reasonRow,
                    {
                      backgroundColor: colors.surface,
                      borderColor: colors.border,
                      borderRadius: colors.radius,
                    },
                  ]}
                >
                  <Feather
                    name={
                      verdict.status === "safe"
                        ? "check"
                        : "alert-circle"
                    }
                    size={16}
                    color={accent}
                  />
                  <Text
                    style={[
                      styles.reasonText,
                      { color: colors.foreground },
                    ]}
                  >
                    {r}
                  </Text>
                </Animated.View>
              ))}
            </View>
          </Animated.View>
        ) : null}

        {(aiLoading || aiVerdict || aiError) && verdict ? (
          <View style={{ marginTop: 22 }}>
            <Text style={[styles.sectionTag, { color: colors.mutedForeground }]}>
              {locale === "ur" ? "اے آئی گہرا تجزیہ" : "Live AI deep analysis"}
            </Text>
            <View style={{ marginTop: 8 }}>
              <AiVerdictCard
                loading={aiLoading}
                error={aiError}
                verdict={aiVerdict}
              />
            </View>
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: 20 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 22,
  },
  title: { fontFamily: "Inter_700Bold", fontSize: 26, letterSpacing: -0.5 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 4 },
  iconBubble: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  inputCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  input: {
    flex: 1,
    fontFamily: "Inter_500Medium",
    fontSize: 14,
    paddingVertical: 0,
  },
  tryLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    letterSpacing: 0.6,
    textTransform: "uppercase",
    marginTop: 24,
    marginBottom: 10,
  },
  sectionTag: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.8,
    textTransform: "uppercase",
  },
  sampleRow: { gap: 10 },
  sampleChip: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
  },
  sampleText: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  sampleHint: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 2 },
  verdictCard: { padding: 20, gap: 12 },
  verdictHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  verdictLabel: {
    color: "rgba(255,255,255,0.75)",
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    letterSpacing: 1,
    textTransform: "uppercase",
  },
  verdictTitle: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 22,
    marginTop: 2,
  },
  verdictUrl: {
    color: "rgba(255,255,255,0.95)",
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  scorePill: {
    backgroundColor: "rgba(0,0,0,0.18)",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    alignItems: "center",
  },
  scoreValue: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 20,
  },
  scoreLabel: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_500Medium",
    fontSize: 9,
    letterSpacing: 0.6,
    textTransform: "uppercase",
  },
  reasonRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
    borderWidth: 1,
  },
  reasonText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13 },
});
