// Secure Vault — REAL biometric (expo-local-authentication) gated access to
// items stored in REAL secure storage (iOS Keychain / Android Keystore).
import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, {
  Easing,
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { GradientButton } from "@/components/GradientButton";
import {
  authenticate,
  getBiometricCapability,
  type BiometricCapability,
} from "@/lib/data/biometric";
import type { VaultItem } from "@/lib/data/mockData";
import { useAppState } from "@/lib/presentation/appState";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

type Editing = {
  id?: string;
  label: string;
  value: string;
  type: VaultItem["type"];
};

export default function VaultScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t, locale } = useI18n();
  const { vault, vaultLoaded, addVaultItem, updateVaultItem, removeVaultItem } =
    useAppState();

  const [unlocked, setUnlocked] = useState(false);
  const [authenticating, setAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [cap, setCap] = useState<BiometricCapability | null>(null);
  const [editing, setEditing] = useState<Editing | null>(null);

  useEffect(() => {
    getBiometricCapability().then(setCap);
  }, []);

  const startAuth = async () => {
    if (authenticating) return;
    setAuthError(null);
    setAuthenticating(true);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    }
    const result = await authenticate(
      locale === "ur"
        ? "محفوظ والٹ کھولنے کے لیے تصدیق کریں"
        : "Authenticate to unlock your secure vault",
    );
    setAuthenticating(false);
    if (result.success) {
      setUnlocked(true);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(
          Haptics.NotificationFeedbackType.Success,
        ).catch(() => {});
      }
    } else if (result.error !== "cancelled") {
      setAuthError(t.authenticationFailed);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(
          Haptics.NotificationFeedbackType.Error,
        ).catch(() => {});
      }
    }
  };

  const onCopy = async (item: VaultItem) => {
    try {
      await Clipboard.setStringAsync(item.value);
      setCopiedId(item.id);
      if (Platform.OS !== "web") {
        Haptics.selectionAsync().catch(() => {});
      }
      setTimeout(() => setCopiedId((c) => (c === item.id ? null : c)), 1400);
    } catch {
      // ignore
    }
  };

  const onConfirmDelete = (item: VaultItem) => {
    if (Platform.OS === "web") {
      const ok =
        typeof globalThis.confirm === "function"
          ? globalThis.confirm(`${t.deleteItem}: ${item.label}?`)
          : true;
      if (ok) removeVaultItem(item.id);
      return;
    }
    Alert.alert(t.deleteItem, item.label, [
      { text: t.cancel, style: "cancel" },
      {
        text: t.delete,
        style: "destructive",
        onPress: () => removeVaultItem(item.id),
      },
    ]);
  };

  const onSave = async () => {
    if (!editing) return;
    const label = editing.label.trim();
    const value = editing.value.trim();
    if (!label || !value) return;
    if (editing.id) {
      await updateVaultItem(editing.id, {
        label,
        value,
        type: editing.type,
      });
    } else {
      await addVaultItem({ label, value, type: editing.type });
    }
    setEditing(null);
  };

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  if (!unlocked) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <View
          style={[
            styles.lockWrap,
            { paddingTop: insets.top + webTopInset + 24 },
          ]}
        >
          <Text style={[styles.title, { color: colors.foreground }]}>
            {t.vaultHeader}
          </Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            {t.vaultSubtitle}
          </Text>

          <View style={styles.bioCenter}>
            <BiometricGlow active={authenticating} />
            <Text
              style={[styles.bioPrompt, { color: colors.foreground }]}
            >
              {authenticating
                ? t.authenticating
                : cap?.primaryLabel
                  ? `${t.biometricPrompt.replace(
                      "Face ID / Fingerprint",
                      cap.primaryLabel,
                    )}`
                  : t.biometricPrompt}
            </Text>
            <Text
              style={[styles.bioHint, { color: colors.mutedForeground }]}
            >
              {vault.length}{" "}
              {locale === "ur" ? "انکرپٹڈ آئٹمز" : "encrypted items"}
              {Platform.OS === "web" ? " · web fallback" : ""}
            </Text>
            {authError ? (
              <Text style={[styles.authError, { color: colors.danger }]}>
                {authError}
              </Text>
            ) : null}
            {cap && cap.available && !cap.enrolled ? (
              <Text style={[styles.bioHint, { color: colors.warning }]}>
                {t.biometricUnavailable}
              </Text>
            ) : null}
            <View style={{ marginTop: 28, width: "100%" }}>
              <GradientButton
                label={t.unlock}
                onPress={startAuth}
                disabled={authenticating}
                icon={<Feather name="lock" size={16} color="#fff" />}
              />
            </View>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingTop: insets.top + webTopInset + 12,
            paddingBottom: 120 + insets.bottom,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>
              {t.vaultHeader}
            </Text>
            <Text style={[styles.sub, { color: colors.mutedForeground }]}>
              {vault.length}{" "}
              {locale === "ur" ? "آئٹمز" : "items"} ·{" "}
              {Platform.OS === "web"
                ? "browser localStorage"
                : Platform.OS === "ios"
                  ? "iOS Keychain"
                  : "Android Keystore"}
            </Text>
          </View>
          <Pressable
            onPress={() => {
              setUnlocked(false);
              setRevealed({});
            }}
            style={[
              styles.iconBubble,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <Feather name="lock" size={18} color={colors.foreground} />
          </Pressable>
        </View>

        <View style={{ marginTop: 16 }}>
          <GradientButton
            label={t.addItem}
            onPress={() =>
              setEditing({ label: "", value: "", type: "password" })
            }
            icon={<Feather name="plus" size={16} color="#fff" />}
          />
        </View>

        {!vaultLoaded ? (
          <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>
            …
          </Text>
        ) : vault.length === 0 ? (
          <View
            style={[
              styles.empty,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
                borderRadius: colors.radius,
              },
            ]}
          >
            <Feather name="shield" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {t.emptyVault}
            </Text>
            <Text
              style={[styles.emptyHint, { color: colors.mutedForeground }]}
            >
              {t.emptyVaultHint}
            </Text>
          </View>
        ) : (
          <View style={{ gap: 12, marginTop: 18 }}>
            {vault.map((item, i) => {
              const isRevealed = !!revealed[item.id];
              const justCopied = copiedId === item.id;
              return (
                <Animated.View
                  key={item.id}
                  entering={FadeInDown.delay(i * 60).duration(380)}
                >
                  <LinearGradient
                    colors={[colors.gradientStart, colors.gradientEnd]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={[
                      styles.vaultCard,
                      { borderRadius: colors.radius },
                    ]}
                  >
                    <View style={styles.cardTop}>
                      <View
                        style={[
                          styles.typeBadge,
                          { backgroundColor: "rgba(255,255,255,0.18)" },
                        ]}
                      >
                        <Feather
                          name={
                            item.type === "card"
                              ? "credit-card"
                              : item.type === "id"
                                ? "user"
                                : item.type === "password"
                                  ? "key"
                                  : "file-text"
                          }
                          size={14}
                          color="#fff"
                        />
                        <Text style={styles.typeText}>
                          {item.type.toUpperCase()}
                        </Text>
                      </View>
                      <View style={{ flexDirection: "row", gap: 6 }}>
                        <Pressable
                          onPress={() =>
                            setRevealed((r) => ({
                              ...r,
                              [item.id]: !r[item.id],
                            }))
                          }
                          style={[
                            styles.iconBtn,
                            { backgroundColor: "rgba(255,255,255,0.18)" },
                          ]}
                        >
                          <Feather
                            name={isRevealed ? "eye-off" : "eye"}
                            size={14}
                            color="#fff"
                          />
                        </Pressable>
                        <Pressable
                          onPress={() => onCopy(item)}
                          style={[
                            styles.iconBtn,
                            { backgroundColor: "rgba(255,255,255,0.18)" },
                          ]}
                        >
                          <Feather
                            name={justCopied ? "check" : "copy"}
                            size={14}
                            color="#fff"
                          />
                        </Pressable>
                        <Pressable
                          onPress={() =>
                            setEditing({
                              id: item.id,
                              label: item.label,
                              value: item.value,
                              type: item.type,
                            })
                          }
                          style={[
                            styles.iconBtn,
                            { backgroundColor: "rgba(255,255,255,0.18)" },
                          ]}
                        >
                          <Feather name="edit-2" size={14} color="#fff" />
                        </Pressable>
                        <Pressable
                          onPress={() => onConfirmDelete(item)}
                          style={[
                            styles.iconBtn,
                            { backgroundColor: "rgba(255,255,255,0.18)" },
                          ]}
                        >
                          <Feather name="trash-2" size={14} color="#fff" />
                        </Pressable>
                      </View>
                    </View>

                    <Text style={styles.label}>{item.label}</Text>

                    {isRevealed ? (
                      <Animated.Text
                        entering={FadeIn.duration(220)}
                        style={styles.value}
                      >
                        {item.value}
                      </Animated.Text>
                    ) : (
                      <Text style={styles.cipher} numberOfLines={1}>
                        {"•".repeat(Math.min(item.value.length, 20))}
                      </Text>
                    )}

                    <View style={styles.cardBottom}>
                      <Feather
                        name="shield"
                        size={12}
                        color="rgba(255,255,255,0.7)"
                      />
                      <Text style={styles.encNote}>
                        {Platform.OS === "ios"
                          ? "Keychain"
                          : Platform.OS === "android"
                            ? "Keystore"
                            : "Browser"}{" "}
                        ·{" "}
                        {Math.max(
                          1,
                          Math.round(
                            (Date.now() - item.updatedAt) / (1000 * 60 * 60),
                          ),
                        )}
                        h ago
                      </Text>
                      {justCopied ? (
                        <Text style={[styles.encNote, { color: "#fff" }]}>
                          · {t.copied}
                        </Text>
                      ) : null}
                    </View>
                  </LinearGradient>
                </Animated.View>
              );
            })}
          </View>
        )}
      </ScrollView>

      <EditModal
        editing={editing}
        onChange={setEditing}
        onSave={onSave}
        onClose={() => setEditing(null)}
      />
    </View>
  );
}

function EditModal({
  editing,
  onChange,
  onSave,
  onClose,
}: {
  editing: Editing | null;
  onChange: (e: Editing | null) => void;
  onSave: () => void;
  onClose: () => void;
}) {
  const { colors } = useTheme();
  const { t } = useI18n();
  const insets = useSafeAreaInsets();

  const types = useMemo(
    () =>
      [
        { key: "password", label: t.typePassword, icon: "key" as const },
        { key: "card", label: t.typeCard, icon: "credit-card" as const },
        { key: "id", label: t.typeId, icon: "user" as const },
        { key: "note", label: t.typeNote, icon: "file-text" as const },
      ] as const,
    [t],
  );

  return (
    <Modal
      visible={!!editing}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={[
          modalStyles.backdrop,
          { paddingBottom: insets.bottom },
        ]}
      >
        <Pressable
          style={modalStyles.dismiss}
          onPress={onClose}
        />
        <View
          style={[
            modalStyles.sheet,
            { backgroundColor: colors.background },
          ]}
        >
          <View style={modalStyles.handle}>
            <View
              style={{
                width: 36,
                height: 4,
                borderRadius: 2,
                backgroundColor: colors.border,
              }}
            />
          </View>
          <Text style={[modalStyles.title, { color: colors.foreground }]}>
            {editing?.id ? t.editItem : t.addItem}
          </Text>

          <Text style={[modalStyles.label, { color: colors.mutedForeground }]}>
            {t.itemType}
          </Text>
          <View style={modalStyles.typeRow}>
            {types.map((typ) => {
              const active = editing?.type === typ.key;
              return (
                <Pressable
                  key={typ.key}
                  onPress={() =>
                    editing && onChange({ ...editing, type: typ.key })
                  }
                  style={[
                    modalStyles.typeChip,
                    {
                      backgroundColor: active ? colors.accent : colors.surface,
                      borderColor: active ? colors.accent : colors.border,
                    },
                  ]}
                >
                  <Feather
                    name={typ.icon}
                    size={14}
                    color={active ? "#fff" : colors.foreground}
                  />
                  <Text
                    style={[
                      modalStyles.typeChipText,
                      { color: active ? "#fff" : colors.foreground },
                    ]}
                  >
                    {typ.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <Text style={[modalStyles.label, { color: colors.mutedForeground }]}>
            {t.itemLabel}
          </Text>
          <TextInput
            value={editing?.label ?? ""}
            onChangeText={(v) =>
              editing && onChange({ ...editing, label: v })
            }
            placeholder="HBL Visa"
            placeholderTextColor={colors.mutedForeground}
            style={[
              modalStyles.input,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
                color: colors.foreground,
                borderRadius: colors.radius,
              },
            ]}
          />

          <Text style={[modalStyles.label, { color: colors.mutedForeground }]}>
            {t.itemValue}
          </Text>
          <TextInput
            value={editing?.value ?? ""}
            onChangeText={(v) =>
              editing && onChange({ ...editing, value: v })
            }
            placeholder="•••• •••• •••• 1234"
            placeholderTextColor={colors.mutedForeground}
            multiline
            style={[
              modalStyles.input,
              modalStyles.multiline,
              {
                backgroundColor: colors.surface,
                borderColor: colors.border,
                color: colors.foreground,
                borderRadius: colors.radius,
              },
            ]}
          />

          <View style={{ marginTop: 18 }}>
            <GradientButton
              label={t.save}
              onPress={onSave}
              disabled={
                !editing?.label.trim() || !editing?.value.trim()
              }
              icon={<Feather name="check" size={16} color="#fff" />}
            />
          </View>
          <Pressable
            onPress={onClose}
            style={modalStyles.cancelBtn}
          >
            <Text style={[modalStyles.cancelText, { color: colors.mutedForeground }]}>
              {t.cancel}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

function BiometricGlow({ active }: { active: boolean }) {
  const { colors } = useTheme();
  const scale = useSharedValue(1);

  useEffect(() => {
    if (active) {
      scale.value = withRepeat(
        withTiming(1.18, { duration: 700, easing: Easing.inOut(Easing.quad) }),
        -1,
        true,
      );
    } else {
      scale.value = 1;
    }
  }, [active, scale]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <View style={styles.bioWrap}>
      <Animated.View
        style={[
          styles.bioGlow,
          { backgroundColor: colors.accent + "33" },
          animStyle,
        ]}
      />
      <View
        style={[styles.bioCore, { backgroundColor: colors.accent }]}
      >
        <Feather name="shield" size={48} color="#fff" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingHorizontal: 20 },
  lockWrap: { flex: 1, paddingHorizontal: 24 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  title: { fontFamily: "Inter_700Bold", fontSize: 26, letterSpacing: -0.5 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 4 },
  iconBubble: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  bioCenter: { flex: 1, alignItems: "center", justifyContent: "center" },
  bioWrap: {
    width: 200,
    height: 200,
    alignItems: "center",
    justifyContent: "center",
  },
  bioGlow: { position: "absolute", width: 200, height: 200, borderRadius: 100 },
  bioCore: {
    width: 130,
    height: 130,
    borderRadius: 65,
    alignItems: "center",
    justifyContent: "center",
  },
  bioPrompt: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
    marginTop: 28,
    textAlign: "center",
  },
  bioHint: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 6,
    textAlign: "center",
  },
  authError: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    marginTop: 10,
    textAlign: "center",
  },
  vaultCard: { padding: 18, gap: 8, minHeight: 160 },
  cardTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  typeBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  typeText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 10,
    letterSpacing: 0.6,
  },
  iconBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  label: {
    color: "rgba(255,255,255,0.75)",
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    letterSpacing: 0.6,
    textTransform: "uppercase",
    marginTop: 14,
  },
  value: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    letterSpacing: 0.4,
  },
  cipher: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_700Bold",
    fontSize: 18,
    letterSpacing: 4,
  },
  cardBottom: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginTop: 12,
    flexWrap: "wrap",
  },
  encNote: {
    color: "rgba(255,255,255,0.75)",
    fontFamily: "Inter_400Regular",
    fontSize: 11,
  },
  empty: {
    alignItems: "center",
    padding: 32,
    marginTop: 24,
    borderWidth: 1,
    gap: 8,
  },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  emptyHint: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    textAlign: "center",
  },
  loadingText: { textAlign: "center", marginTop: 30 },
});

const modalStyles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "flex-end",
  },
  dismiss: { flex: 1 },
  sheet: {
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 20,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
  },
  handle: { alignItems: "center", marginBottom: 12 },
  title: {
    fontFamily: "Inter_700Bold",
    fontSize: 20,
    marginBottom: 16,
  },
  label: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
    letterSpacing: 0.7,
    textTransform: "uppercase",
    marginTop: 14,
    marginBottom: 8,
  },
  typeRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  typeChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
  },
  typeChipText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  input: {
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontFamily: "Inter_500Medium",
    fontSize: 14,
  },
  multiline: { minHeight: 70, textAlignVertical: "top" },
  cancelBtn: { alignItems: "center", paddingVertical: 12, marginTop: 4 },
  cancelText: { fontFamily: "Inter_500Medium", fontSize: 13 },
});
