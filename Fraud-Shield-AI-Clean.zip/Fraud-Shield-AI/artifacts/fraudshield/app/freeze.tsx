// Emergency Freeze modal — confirm + show blocked-state animation.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useEffect } from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, {
  Easing,
  FadeIn,
  FadeInUp,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { GradientButton } from "@/components/GradientButton";
import { useAppState } from "@/lib/presentation/appState";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

export default function FreezeScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useI18n();
  const { frozen, freezeAccounts, unfreezeAccounts } = useAppState();

  const onConfirm = () => {
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(
        Haptics.NotificationFeedbackType.Warning,
      ).catch(() => {});
    }
    freezeAccounts();
  };

  const onUnfreeze = () => {
    unfreezeAccounts();
    router.back();
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <LinearGradient
        colors={
          frozen
            ? [colors.dangerGradientStart, colors.dangerGradientEnd]
            : [colors.gradientStart, colors.gradientEnd]
        }
        style={[StyleSheet.absoluteFill]}
      />

      <View
        style={[
          styles.wrap,
          {
            paddingTop: insets.top + 16,
            paddingBottom: insets.bottom + 24,
          },
        ]}
      >
        <View style={styles.topBar}>
          <Pressable
            onPress={() => router.back()}
            style={styles.closeBtn}
          >
            <Feather name="x" size={20} color="#fff" />
          </Pressable>
        </View>

        <View style={styles.center}>
          <PulsingShield active={frozen} />

          <Animated.Text entering={FadeInUp.duration(500)} style={styles.title}>
            {frozen ? t.accountsFrozen : t.freezeTitle}
          </Animated.Text>

          <Animated.Text
            entering={FadeIn.delay(200).duration(500)}
            style={styles.body}
          >
            {frozen
              ? "All linked cards, transfers, and online payments are blocked. Your bank has been notified."
              : t.freezeWarning}
          </Animated.Text>

          {frozen ? (
            <Animated.View
              entering={FadeInUp.delay(300)}
              style={styles.statusRow}
            >
              <StatusBadge label="Cards" />
              <StatusBadge label="Transfers" />
              <StatusBadge label="Online Payments" />
            </Animated.View>
          ) : null}
        </View>

        <View style={{ width: "100%", gap: 10 }}>
          {frozen ? (
            <GradientButton
              label={t.unfreeze}
              variant="ghost"
              onPress={onUnfreeze}
              icon={<Feather name="unlock" size={16} color={colors.foreground} />}
            />
          ) : (
            <>
              <GradientButton
                label={t.confirmFreeze}
                variant="danger"
                onPress={onConfirm}
                icon={<Feather name="alert-octagon" size={16} color="#fff" />}
              />
              <Pressable
                onPress={() => router.back()}
                style={styles.cancelBtn}
              >
                <Text style={styles.cancelText}>{t.cancel}</Text>
              </Pressable>
            </>
          )}
        </View>
      </View>
    </View>
  );
}

function PulsingShield({ active }: { active: boolean }) {
  const scale = useSharedValue(1);

  useEffect(() => {
    scale.value = withRepeat(
      withTiming(active ? 1.18 : 1.06, {
        duration: active ? 600 : 1200,
        easing: Easing.inOut(Easing.quad),
      }),
      -1,
      true,
    );
  }, [active, scale]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <View style={styles.shieldWrap}>
      <Animated.View style={[styles.shieldGlow, animStyle]} />
      <View style={styles.shieldCore}>
        <Feather
          name={active ? "lock" : "alert-octagon"}
          size={64}
          color="#fff"
        />
      </View>
    </View>
  );
}

function StatusBadge({ label }: { label: string }) {
  return (
    <View style={styles.statusBadge}>
      <Feather name="check" size={12} color="#fff" />
      <Text style={styles.statusText}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    paddingHorizontal: 24,
    alignItems: "center",
    justifyContent: "space-between",
  },
  topBar: { flexDirection: "row", justifyContent: "flex-end", width: "100%" },
  closeBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.18)",
  },
  center: { alignItems: "center", flex: 1, justifyContent: "center" },
  shieldWrap: {
    width: 220,
    height: 220,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 28,
  },
  shieldGlow: {
    position: "absolute",
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: "rgba(255,255,255,0.2)",
  },
  shieldCore: {
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: "rgba(255,255,255,0.18)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.4)",
  },
  title: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 26,
    textAlign: "center",
    letterSpacing: -0.4,
  },
  body: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    textAlign: "center",
    marginTop: 12,
    lineHeight: 20,
    paddingHorizontal: 12,
  },
  statusRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: 8,
    marginTop: 22,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 999,
  },
  statusText: { color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 12 },
  cancelBtn: { padding: 14, alignItems: "center" },
  cancelText: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
});
