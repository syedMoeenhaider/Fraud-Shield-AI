// Lightweight i18n provider with Urdu + English support and a mock voice helper.
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { loadJson, saveJson } from "@/lib/data/storage";

export type Locale = "en" | "ur";

const STORAGE_KEY = "fraudshield/locale";

type Strings = {
  appName: string;
  tagline: string;
  // tabs
  dashboard: string;
  scanner: string;
  link: string;
  vault: string;
  settings: string;
  // dashboard
  goodMorning: string;
  securityScore: string;
  protected: string;
  monitoring: string;
  recentActivity: string;
  alerts: string;
  noAlerts: string;
  emergencyFreeze: string;
  freezeDescription: string;
  quickActions: string;
  scanSms: string;
  checkLink: string;
  openVault: string;
  viewAll: string;
  // sms
  smsHeader: string;
  smsSubtitle: string;
  safe: string;
  suspicious: string;
  dangerous: string;
  matched: string;
  rescan: string;
  // link
  linkHeader: string;
  linkSubtitle: string;
  enterUrl: string;
  analyze: string;
  trySample: string;
  result: string;
  riskScore: string;
  // vault
  vaultHeader: string;
  vaultSubtitle: string;
  unlock: string;
  authenticating: string;
  biometricPrompt: string;
  cancel: string;
  reveal: string;
  hide: string;
  // freeze
  freezeTitle: string;
  freezeWarning: string;
  confirmFreeze: string;
  accountsFrozen: string;
  unfreeze: string;
  // settings
  language: string;
  theme: string;
  light: string;
  dark: string;
  voice: string;
  speak: string;
  voiceHint: string;
  about: string;
  aboutBody: string;
  // vault CRUD
  addItem: string;
  editItem: string;
  deleteItem: string;
  itemLabel: string;
  itemValue: string;
  itemType: string;
  save: string;
  delete: string;
  emptyVault: string;
  emptyVaultHint: string;
  copy: string;
  copied: string;
  biometricUnavailable: string;
  authenticationFailed: string;
  // scanner CRUD
  addMessage: string;
  pasteMessage: string;
  senderLabel: string;
  bodyLabel: string;
  saveAndAnalyze: string;
  emptyInbox: string;
  emptyInboxHint: string;
  deleteMessage: string;
  // types
  typeCard: string;
  typePassword: string;
  typeId: string;
  typeNote: string;
};

const en: Strings = {
  appName: "FraudShield AI",
  tagline: "Real-time protection for your money",
  dashboard: "Home",
  scanner: "SMS",
  link: "Links",
  vault: "Vault",
  settings: "Settings",
  goodMorning: "Welcome back",
  securityScore: "Security Score",
  protected: "Protected",
  monitoring: "Monitoring 24/7",
  recentActivity: "Recent Activity",
  alerts: "AI Alerts",
  noAlerts: "All clear — no fraud detected",
  emergencyFreeze: "Emergency Freeze",
  freezeDescription: "Instantly block every connected account",
  quickActions: "Quick Actions",
  scanSms: "Scan SMS",
  checkLink: "Check Link",
  openVault: "Open Vault",
  viewAll: "View all",
  smsHeader: "SMS Scanner",
  smsSubtitle: "AI-powered phishing detection",
  safe: "Safe",
  suspicious: "Suspicious",
  dangerous: "Dangerous",
  matched: "Triggers",
  rescan: "Rescan inbox",
  linkHeader: "Link Safety",
  linkSubtitle: "Inspect any URL before you tap it",
  enterUrl: "Paste a link to analyze",
  analyze: "Analyze",
  trySample: "Try sample links",
  result: "Result",
  riskScore: "Risk score",
  vaultHeader: "Secure Vault",
  vaultSubtitle: "End-to-end encrypted storage",
  unlock: "Unlock with biometrics",
  authenticating: "Authenticating",
  biometricPrompt: "Use Face ID / Fingerprint to continue",
  cancel: "Cancel",
  reveal: "Reveal",
  hide: "Hide",
  freezeTitle: "Freeze All Accounts?",
  freezeWarning:
    "This will simulate blocking every linked card and bank account immediately.",
  confirmFreeze: "Yes, freeze now",
  accountsFrozen: "All accounts frozen",
  unfreeze: "Restore accounts",
  language: "Language",
  theme: "Appearance",
  light: "Light",
  dark: "Dark",
  voice: "Voice Assistant",
  speak: "Tap to speak",
  voiceHint: "Try: \"Is my account safe?\"",
  about: "About",
  aboutBody:
    "FraudShield AI is a hackathon prototype that detects suspicious banking activity, phishing SMS, and unsafe links — all on-device.",
  addItem: "Add new",
  editItem: "Edit",
  deleteItem: "Delete",
  itemLabel: "Label",
  itemValue: "Secret value",
  itemType: "Type",
  save: "Save",
  delete: "Delete",
  emptyVault: "Your vault is empty",
  emptyVaultHint: "Add a card, password, or note to keep it encrypted.",
  copy: "Copy",
  copied: "Copied",
  biometricUnavailable:
    "No biometric is set up on this device. The system will use your device passcode instead.",
  authenticationFailed: "Authentication failed. Try again.",
  addMessage: "Add real message",
  pasteMessage:
    "Paste an SMS you received and we'll analyze it with live AI.",
  senderLabel: "Sender (e.g. JAZZCASH, +92300...)",
  bodyLabel: "Message body",
  saveAndAnalyze: "Save & analyze",
  emptyInbox: "No messages yet",
  emptyInboxHint: "Add an SMS you received to scan it for scams.",
  deleteMessage: "Delete message",
  typeCard: "Card",
  typePassword: "Password",
  typeId: "ID",
  typeNote: "Note",
};

const ur: Strings = {
  appName: "فراڈ شیلڈ اے آئی",
  tagline: "آپ کے پیسوں کا حقیقی وقت میں تحفظ",
  dashboard: "ہوم",
  scanner: "ایس ایم ایس",
  link: "لنکس",
  vault: "والٹ",
  settings: "ترتیبات",
  goodMorning: "خوش آمدید",
  securityScore: "سکیورٹی اسکور",
  protected: "محفوظ",
  monitoring: "چوبیس گھنٹے نگرانی",
  recentActivity: "حالیہ سرگرمی",
  alerts: "اے آئی الرٹس",
  noAlerts: "سب کچھ صاف — کوئی فراڈ نہیں",
  emergencyFreeze: "ہنگامی فریز",
  freezeDescription: "تمام جڑے اکاؤنٹس فوراً بلاک کریں",
  quickActions: "فوری اقدامات",
  scanSms: "ایس ایم ایس اسکین",
  checkLink: "لنک چیک",
  openVault: "والٹ کھولیں",
  viewAll: "سب دیکھیں",
  smsHeader: "ایس ایم ایس اسکینر",
  smsSubtitle: "اے آئی فشنگ ڈیٹیکشن",
  safe: "محفوظ",
  suspicious: "مشکوک",
  dangerous: "خطرناک",
  matched: "اشارے",
  rescan: "دوبارہ اسکین",
  linkHeader: "لنک سیفٹی",
  linkSubtitle: "کسی بھی لنک پر کلک سے پہلے جانچیں",
  enterUrl: "تجزیے کے لیے لنک پیسٹ کریں",
  analyze: "تجزیہ",
  trySample: "نمونہ لنکس آزمائیں",
  result: "نتیجہ",
  riskScore: "خطرے کا اسکور",
  vaultHeader: "محفوظ والٹ",
  vaultSubtitle: "اینڈ ٹو اینڈ انکرپٹڈ اسٹوریج",
  unlock: "بایومیٹرک سے کھولیں",
  authenticating: "تصدیق ہو رہی ہے",
  biometricPrompt: "جاری رکھنے کے لیے فیس آئی ڈی / فنگر پرنٹ استعمال کریں",
  cancel: "منسوخ کریں",
  reveal: "ظاہر کریں",
  hide: "چھپائیں",
  freezeTitle: "تمام اکاؤنٹس فریز کریں؟",
  freezeWarning: "یہ فوری طور پر تمام جڑے ہوئے اکاؤنٹس کو بلاک کر دے گا۔",
  confirmFreeze: "ہاں، ابھی فریز کریں",
  accountsFrozen: "تمام اکاؤنٹس فریز ہیں",
  unfreeze: "اکاؤنٹس بحال کریں",
  language: "زبان",
  theme: "ظاہری شکل",
  light: "روشن",
  dark: "گہرا",
  voice: "وائس اسسٹنٹ",
  speak: "بولنے کے لیے ٹیپ کریں",
  voiceHint: "آزمائیں: \"کیا میرا اکاؤنٹس محفوظ ہے؟\"",
  about: "تعارف",
  aboutBody:
    "فراڈ شیلڈ اے آئی ایک ہیکاتھون پروٹوٹائپ ہے جو مشکوک بینکنگ سرگرمی، فشنگ ایس ایم ایس اور غیر محفوظ لنکس کا پتہ لگاتا ہے۔",
  addItem: "نیا شامل کریں",
  editItem: "ترمیم",
  deleteItem: "حذف کریں",
  itemLabel: "عنوان",
  itemValue: "خفیہ ویلیو",
  itemType: "قسم",
  save: "محفوظ کریں",
  delete: "حذف",
  emptyVault: "آپ کا والٹ خالی ہے",
  emptyVaultHint: "کارڈ، پاس ورڈ یا نوٹ شامل کریں — انکرپٹڈ رہے گا۔",
  copy: "کاپی",
  copied: "کاپی ہو گیا",
  biometricUnavailable:
    "اس ڈیوائس پر بایومیٹرک نہیں۔ سسٹم ڈیوائس پاس کوڈ استعمال کرے گا۔",
  authenticationFailed: "تصدیق ناکام۔ دوبارہ کوشش کریں۔",
  addMessage: "اصل پیغام شامل کریں",
  pasteMessage: "وہ ایس ایم ایس پیسٹ کریں جو آپ کو موصول ہوا — ہم لائیو اے آئی سے جانچیں گے۔",
  senderLabel: "بھیجنے والا (مثلاً JAZZCASH، +92300...)",
  bodyLabel: "پیغام کا متن",
  saveAndAnalyze: "محفوظ کریں اور جانچیں",
  emptyInbox: "ابھی کوئی پیغام نہیں",
  emptyInboxHint: "ایس ایم ایس شامل کریں اور اسکیم کے لیے اسکین کریں۔",
  deleteMessage: "پیغام حذف کریں",
  typeCard: "کارڈ",
  typePassword: "پاس ورڈ",
  typeId: "شناخت",
  typeNote: "نوٹ",
};

const DICT: Record<Locale, Strings> = { en, ur };

const VOICE_RESPONSES: Record<Locale, string[]> = {
  en: [
    "Your accounts look secure. Security score is 87.",
    "I've spotted one suspicious transaction this week.",
    "No phishing attempts detected in the last 24 hours.",
    "Your vault is locked and encrypted.",
  ],
  ur: [
    "آپ کے اکاؤنٹس محفوظ ہیں۔ سکیورٹی اسکور 87 ہے۔",
    "اس ہفتے ایک مشکوک ٹرانزیکشن دیکھی گئی ہے۔",
    "گزشتہ چوبیس گھنٹوں میں کوئی فشنگ کوشش نہیں ملی۔",
    "آپ کا والٹ مقفل اور انکرپٹڈ ہے۔",
  ],
};

type I18nContext = {
  locale: Locale;
  t: Strings;
  setLocale: (l: Locale) => void;
  isRtl: boolean;
  speak: () => string;
};

const Ctx = createContext<I18nContext | null>(null);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("en");

  useEffect(() => {
    loadJson<Locale>(STORAGE_KEY, "en").then(setLocaleState);
  }, []);

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    saveJson(STORAGE_KEY, l);
  }, []);

  const speak = useCallback(() => {
    const list = VOICE_RESPONSES[locale];
    return list[Math.floor(Math.random() * list.length)] ?? "";
  }, [locale]);

  const value = useMemo<I18nContext>(
    () => ({
      locale,
      t: DICT[locale],
      setLocale,
      isRtl: locale === "ur",
      speak,
    }),
    [locale, setLocale, speak],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n(): I18nContext {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider");
  return ctx;
}
