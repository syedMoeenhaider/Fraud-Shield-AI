// Theme provider — exposes the current color palette and lets the user
// override the system preference (light/dark/system).
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useColorScheme } from "react-native";

import colors from "@/constants/colors";
import { loadJson, saveJson } from "@/lib/data/storage";

export type ThemeMode = "system" | "light" | "dark";
export type Palette = typeof colors.light & { radius: number };

const STORAGE_KEY = "fraudshield/theme-mode";

type ThemeContext = {
  mode: ThemeMode;
  setMode: (m: ThemeMode) => void;
  isDark: boolean;
  colors: Palette;
};

const Ctx = createContext<ThemeContext | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>("system");

  useEffect(() => {
    loadJson<ThemeMode>(STORAGE_KEY, "system").then(setModeState);
  }, []);

  const setMode = useCallback((m: ThemeMode) => {
    setModeState(m);
    saveJson(STORAGE_KEY, m);
  }, []);

  const isDark =
    mode === "dark" || (mode === "system" && system === "dark");

  const palette = useMemo<Palette>(
    () => ({
      ...(isDark ? colors.dark : colors.light),
      radius: colors.radius,
    }),
    [isDark],
  );

  const value = useMemo<ThemeContext>(
    () => ({ mode, setMode, isDark, colors: palette }),
    [mode, setMode, isDark, palette],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTheme(): ThemeContext {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTheme must be used inside ThemeProvider");
  return ctx;
}

export function useAppColors(): Palette {
  return useTheme().colors;
}
