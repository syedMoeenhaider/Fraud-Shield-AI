// Global app state: transactions, messages, vault items, freeze status, and
// risky-click counter. Vault items live in REAL secure storage (Keychain on iOS,
// Keystore on Android). Other state lives in AsyncStorage.
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  SEED_MESSAGES,
  SEED_TRANSACTIONS,
  SEED_VAULT,
  type Message,
  type Transaction,
  type VaultItem,
} from "@/lib/data/mockData";
import {
  loadSecureJson,
  saveSecureJson,
} from "@/lib/data/secureStorage";
import { loadJson, saveJson } from "@/lib/data/storage";
import { computeSecurityScore } from "@/lib/domain/analyzers";

const KEYS = {
  txs: "fraudshield/transactions",
  msgs: "fraudshield/messages",
  vault: "fraudshield/vault_v2", // stored in expo-secure-store
  vaultSeeded: "fraudshield/vault_seeded",
  riskyClicks: "fraudshield/riskyClicks",
  frozen: "fraudshield/frozen",
};

type AppState = {
  transactions: Transaction[];
  messages: Message[];
  vault: VaultItem[];
  vaultLoaded: boolean;
  riskyClicks: number;
  frozen: boolean;
  securityScore: number;
  freezeAccounts: () => void;
  unfreezeAccounts: () => void;
  registerRiskyClick: () => void;
  resetDemo: () => void;

  // Vault CRUD
  addVaultItem: (item: Omit<VaultItem, "id" | "updatedAt">) => Promise<void>;
  updateVaultItem: (id: string, patch: Partial<Omit<VaultItem, "id">>) => Promise<void>;
  removeVaultItem: (id: string) => Promise<void>;

  // Message CRUD
  addMessage: (msg: Omit<Message, "id" | "timestamp">) => Promise<Message>;
  removeMessage: (id: string) => Promise<void>;
  clearMessages: () => Promise<void>;
};

const Ctx = createContext<AppState | null>(null);

function genId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  const [transactions, setTransactions] = useState<Transaction[]>(SEED_TRANSACTIONS);
  const [messages, setMessages] = useState<Message[]>(SEED_MESSAGES);
  const [vault, setVault] = useState<VaultItem[]>([]);
  const [vaultLoaded, setVaultLoaded] = useState(false);
  const [riskyClicks, setRiskyClicks] = useState<number>(0);
  const [frozen, setFrozen] = useState<boolean>(false);

  // Hydrate from storage on mount.
  useEffect(() => {
    (async () => {
      const [t, m, r, f, seeded] = await Promise.all([
        loadJson<Transaction[]>(KEYS.txs, SEED_TRANSACTIONS),
        loadJson<Message[]>(KEYS.msgs, SEED_MESSAGES),
        loadJson<number>(KEYS.riskyClicks, 0),
        loadJson<boolean>(KEYS.frozen, false),
        loadJson<boolean>(KEYS.vaultSeeded, false),
      ]);
      setTransactions(t);
      setMessages(m);
      setRiskyClicks(r);
      setFrozen(f);

      // Load vault from secure storage. Seed once on first run.
      const v = await loadSecureJson<VaultItem[]>(KEYS.vault, []);
      if (!seeded && v.length === 0) {
        await saveSecureJson(KEYS.vault, SEED_VAULT);
        await saveJson(KEYS.vaultSeeded, true);
        setVault(SEED_VAULT);
      } else {
        setVault(v);
      }
      setVaultLoaded(true);
    })();
  }, []);

  const freezeAccounts = useCallback(() => {
    setFrozen(true);
    saveJson(KEYS.frozen, true);
  }, []);

  const unfreezeAccounts = useCallback(() => {
    setFrozen(false);
    saveJson(KEYS.frozen, false);
  }, []);

  const registerRiskyClick = useCallback(() => {
    setRiskyClicks((c) => {
      const next = c + 1;
      saveJson(KEYS.riskyClicks, next);
      return next;
    });
  }, []);

  const resetDemo = useCallback(() => {
    setTransactions(SEED_TRANSACTIONS);
    setMessages(SEED_MESSAGES);
    setVault(SEED_VAULT);
    setRiskyClicks(0);
    setFrozen(false);
    saveJson(KEYS.txs, SEED_TRANSACTIONS);
    saveJson(KEYS.msgs, SEED_MESSAGES);
    saveSecureJson(KEYS.vault, SEED_VAULT);
    saveJson(KEYS.vaultSeeded, true);
    saveJson(KEYS.riskyClicks, 0);
    saveJson(KEYS.frozen, false);
  }, []);

  const addVaultItem = useCallback(
    async (item: Omit<VaultItem, "id" | "updatedAt">) => {
      const newItem: VaultItem = {
        ...item,
        id: genId("v"),
        updatedAt: Date.now(),
      };
      setVault((prev) => {
        const next = [newItem, ...prev];
        saveSecureJson(KEYS.vault, next);
        return next;
      });
    },
    [],
  );

  const updateVaultItem = useCallback(
    async (id: string, patch: Partial<Omit<VaultItem, "id">>) => {
      setVault((prev) => {
        const next = prev.map((v) =>
          v.id === id ? { ...v, ...patch, updatedAt: Date.now() } : v,
        );
        saveSecureJson(KEYS.vault, next);
        return next;
      });
    },
    [],
  );

  const removeVaultItem = useCallback(async (id: string) => {
    setVault((prev) => {
      const next = prev.filter((v) => v.id !== id);
      saveSecureJson(KEYS.vault, next);
      return next;
    });
  }, []);

  const addMessage = useCallback(
    async (msg: Omit<Message, "id" | "timestamp">) => {
      const newMsg: Message = {
        ...msg,
        id: genId("m"),
        timestamp: Date.now(),
      };
      setMessages((prev) => {
        const next = [newMsg, ...prev];
        saveJson(KEYS.msgs, next);
        return next;
      });
      return newMsg;
    },
    [],
  );

  const removeMessage = useCallback(async (id: string) => {
    setMessages((prev) => {
      const next = prev.filter((m) => m.id !== id);
      saveJson(KEYS.msgs, next);
      return next;
    });
  }, []);

  const clearMessages = useCallback(async () => {
    setMessages([]);
    await saveJson(KEYS.msgs, [] as Message[]);
  }, []);

  const securityScore = useMemo(
    () =>
      computeSecurityScore({
        transactions,
        messages,
        riskyClicks,
        vaultProtected: vault.length > 0,
      }),
    [transactions, messages, riskyClicks, vault.length],
  );

  const value = useMemo<AppState>(
    () => ({
      transactions,
      messages,
      vault,
      vaultLoaded,
      riskyClicks,
      frozen,
      securityScore,
      freezeAccounts,
      unfreezeAccounts,
      registerRiskyClick,
      resetDemo,
      addVaultItem,
      updateVaultItem,
      removeVaultItem,
      addMessage,
      removeMessage,
      clearMessages,
    }),
    [
      transactions,
      messages,
      vault,
      vaultLoaded,
      riskyClicks,
      frozen,
      securityScore,
      freezeAccounts,
      unfreezeAccounts,
      registerRiskyClick,
      resetDemo,
      addVaultItem,
      updateVaultItem,
      removeVaultItem,
      addMessage,
      removeMessage,
      clearMessages,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAppState(): AppState {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAppState must be used inside AppStateProvider");
  return ctx;
}
