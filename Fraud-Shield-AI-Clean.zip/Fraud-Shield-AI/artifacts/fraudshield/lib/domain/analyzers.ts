// Domain layer — pure logic for fraud detection, SMS analysis, and link safety.
// Kept framework-agnostic so it can be reused or unit tested.

import type { Message, Transaction } from "@/lib/data/mockData";

export type FraudFlag =
  | "large-amount"
  | "new-device"
  | "foreign-location"
  | "high-risk-category"
  | "rapid-succession";

export type FraudVerdict = {
  riskScore: number; // 0–100
  flags: FraudFlag[];
  reason: string;
};

const TRUSTED_DEVICES = new Set(["iPhone 15 Pro", "MacBook Pro"]);
const TRUSTED_LOCATIONS = ["Karachi", "Lahore", "Islamabad", "PK"];
const HIGH_RISK_CATEGORIES = new Set(["Wire Transfer", "Crypto"]);

export function analyzeTransaction(tx: Transaction): FraudVerdict {
  const flags: FraudFlag[] = [];
  let score = 0;

  if (tx.amount >= 100000) {
    flags.push("large-amount");
    score += 35;
  } else if (tx.amount >= 50000) {
    score += 15;
  }

  if (!TRUSTED_DEVICES.has(tx.device)) {
    flags.push("new-device");
    score += 25;
  }

  const isTrustedLocation = TRUSTED_LOCATIONS.some((loc) =>
    tx.location.includes(loc),
  );
  if (!isTrustedLocation) {
    flags.push("foreign-location");
    score += 25;
  }

  if (HIGH_RISK_CATEGORIES.has(tx.category)) {
    flags.push("high-risk-category");
    score += 15;
  }

  score = Math.min(100, score);

  let reason = "Normal activity";
  if (score >= 70) reason = "Suspicious activity detected";
  else if (score >= 40) reason = "Unusual pattern — review";

  return { riskScore: score, flags, reason };
}

export type MessageRisk = "safe" | "suspicious" | "danger";
export type MessageVerdict = {
  risk: MessageRisk;
  matchedKeywords: string[];
  hasLink: boolean;
};

const PHISHING_KEYWORDS = [
  "otp",
  "urgent",
  "account blocked",
  "click link",
  "verify",
  "suspended",
  "lucky draw",
  "won",
  "claim",
  "password",
  "pin",
  "share",
  "reactivate",
];

const URL_REGEX = /(https?:\/\/[^\s]+|bit\.ly\/[^\s]+|tinyurl\.com\/[^\s]+)/i;

export function analyzeMessage(message: Message): MessageVerdict {
  const lower = message.body.toLowerCase();
  const matched = PHISHING_KEYWORDS.filter((k) => lower.includes(k));
  const hasLink = URL_REGEX.test(message.body);

  let risk: MessageRisk = "safe";
  if (matched.length >= 2 || (matched.length >= 1 && hasLink)) {
    risk = "danger";
  } else if (matched.length === 1 || hasLink) {
    risk = "suspicious";
  }

  return { risk, matchedKeywords: matched, hasLink };
}

export type LinkVerdict = {
  status: "safe" | "warning" | "danger";
  score: number;
  reasons: string[];
};

const KNOWN_SAFE_DOMAINS = [
  "google.com",
  "apple.com",
  "microsoft.com",
  "github.com",
  "statebankofpakistan.org.pk",
  "hbl.com",
  "ubl.com.pk",
  "meezanbank.com",
];

const KNOWN_SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"];
const SUSPICIOUS_TLDS = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz"];
const PHISHING_HINT_WORDS = [
  "secure",
  "verify",
  "login",
  "update",
  "wallet",
  "support",
  "claim",
  "free",
  "prize",
  "bank-",
];

export function checkLink(url: string): LinkVerdict {
  const reasons: string[] = [];
  let score = 0;
  let cleaned = url.trim();
  if (!/^https?:\/\//i.test(cleaned)) cleaned = `http://${cleaned}`;

  let host = "";
  try {
    host = new URL(cleaned).hostname.toLowerCase();
  } catch {
    return {
      status: "danger",
      score: 100,
      reasons: ["Malformed URL — cannot be parsed"],
    };
  }

  if (cleaned.startsWith("http://")) {
    reasons.push("Uses insecure HTTP (no encryption)");
    score += 25;
  }

  if (KNOWN_SAFE_DOMAINS.some((d) => host === d || host.endsWith(`.${d}`))) {
    return {
      status: "safe",
      score: 5,
      reasons: ["Domain is on the trusted whitelist"],
    };
  }

  if (KNOWN_SHORTENERS.some((s) => host.includes(s))) {
    reasons.push("URL shortener — destination is hidden");
    score += 30;
  }

  if (SUSPICIOUS_TLDS.some((tld) => host.endsWith(tld))) {
    reasons.push(`Suspicious top-level domain (${host.split(".").pop()})`);
    score += 35;
  }

  const hintHits = PHISHING_HINT_WORDS.filter((w) => host.includes(w));
  if (hintHits.length > 0) {
    reasons.push(`Domain contains phishing keywords: ${hintHits.join(", ")}`);
    score += 20 * hintHits.length;
  }

  // IP-based hostnames
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) {
    reasons.push("Hostname is a raw IP address");
    score += 30;
  }

  // Excessive subdomains
  if (host.split(".").length >= 4) {
    reasons.push("Unusually long subdomain chain");
    score += 10;
  }

  score = Math.min(100, score);

  let status: LinkVerdict["status"] = "safe";
  if (score >= 50) status = "danger";
  else if (score >= 20) status = "warning";

  if (reasons.length === 0) reasons.push("No major risk signals detected");

  return { status, score, reasons };
}

export function computeSecurityScore(args: {
  transactions: Transaction[];
  messages: Message[];
  riskyClicks: number;
  vaultProtected: boolean;
}): number {
  const { transactions, messages, riskyClicks, vaultProtected } = args;

  let score = 100;

  for (const tx of transactions) {
    const v = analyzeTransaction(tx);
    if (v.riskScore >= 70) score -= 8;
    else if (v.riskScore >= 40) score -= 3;
  }

  for (const m of messages) {
    const v = analyzeMessage(m);
    if (v.risk === "danger") score -= 5;
    else if (v.risk === "suspicious") score -= 2;
  }

  score -= riskyClicks * 4;
  if (!vaultProtected) score -= 10;

  return Math.max(0, Math.min(100, Math.round(score)));
}
