// URL Extractor — equivalent to the Android regex URL detection logic.
// Extracts ALL links from an SMS body and classifies them.

// Comprehensive URL regex: handles http/https, bare domains, shorteners.
const URL_PATTERN =
  /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+(?:\/[^\s,;'"<>()[\]]*)?/gi;

// Shortener domains that hide the real destination.
const SHORTENER_DOMAINS = [
  "bit.ly",
  "tinyurl.com",
  "t.co",
  "goo.gl",
  "ow.ly",
  "is.gd",
  "buff.ly",
  "ift.tt",
  "rb.gy",
  "cutt.ly",
];

// Free hosting / high-abuse TLDs.
const SUSPICIOUS_TLDS = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".click"];

export type ExtractedUrl = {
  raw: string;          // as it appeared in the message
  normalized: string;   // with https:// prefix
  isShortened: boolean; // bit.ly etc.
  isSuspicious: boolean;// bad TLD or phishing keyword
};

/**
 * Extract all URLs from a block of text (SMS body).
 * Returns unique, deduplicated results.
 */
export function extractUrls(text: string): ExtractedUrl[] {
  const matches = text.match(URL_PATTERN) ?? [];
  const seen = new Set<string>();
  const results: ExtractedUrl[] = [];

  for (const raw of matches) {
    const normalized = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;

    let host = "";
    try {
      host = new URL(normalized).hostname.toLowerCase();
    } catch {
      continue; // skip malformed
    }

    if (seen.has(host)) continue;
    seen.add(host);

    const isShortened = SHORTENER_DOMAINS.some((s) => host.includes(s));
    const isSuspicious =
      SUSPICIOUS_TLDS.some((tld) => host.endsWith(tld)) ||
      isShortened ||
      /^\d{1,3}(\.\d{1,3}){3}$/.test(host); // raw IP

    results.push({ raw, normalized, isShortened, isSuspicious });
  }

  return results;
}

/**
 * Quick check: does this text contain any URLs?
 */
export function hasAnyUrl(text: string): boolean {
  return URL_PATTERN.test(text);
}

/**
 * Quick check: does this text contain suspicious URLs?
 */
export function hasSuspiciousUrl(text: string): boolean {
  // Reset lastIndex since the regex is global.
  URL_PATTERN.lastIndex = 0;
  return extractUrls(text).some((u) => u.isSuspicious);
}
