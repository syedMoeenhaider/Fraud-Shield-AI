// Real secure storage layer.
// - On native: expo-secure-store (iOS Keychain / Android Keystore — hardware-backed).
// - On web: localStorage (browsers don't expose a hardware-backed keystore).
// We chunk values because SecureStore caps each value at ~2KB.
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

const CHUNK = 1800;
const PREFIX = "fraudshield_secure_";

async function getRaw(key: string): Promise<string | null> {
  if (Platform.OS === "web") {
    try {
      return globalThis.localStorage?.getItem(PREFIX + key) ?? null;
    } catch {
      return null;
    }
  }
  // Read until we find no more chunks.
  const head = await SecureStore.getItemAsync(PREFIX + key);
  if (head == null) return null;
  if (!head.startsWith("CHUNKED:")) return head;
  const count = Number(head.slice("CHUNKED:".length));
  if (!Number.isFinite(count) || count <= 0) return null;
  const parts: string[] = [];
  for (let i = 0; i < count; i += 1) {
    const part = await SecureStore.getItemAsync(`${PREFIX}${key}__${i}`);
    if (part == null) return null;
    parts.push(part);
  }
  return parts.join("");
}

async function setRaw(key: string, value: string): Promise<void> {
  if (Platform.OS === "web") {
    try {
      globalThis.localStorage?.setItem(PREFIX + key, value);
    } catch {
      // ignore
    }
    return;
  }
  if (value.length <= CHUNK) {
    await SecureStore.setItemAsync(PREFIX + key, value);
    return;
  }
  const count = Math.ceil(value.length / CHUNK);
  await SecureStore.setItemAsync(PREFIX + key, `CHUNKED:${count}`);
  for (let i = 0; i < count; i += 1) {
    await SecureStore.setItemAsync(
      `${PREFIX}${key}__${i}`,
      value.slice(i * CHUNK, (i + 1) * CHUNK),
    );
  }
}

async function deleteRaw(key: string): Promise<void> {
  if (Platform.OS === "web") {
    try {
      globalThis.localStorage?.removeItem(PREFIX + key);
    } catch {
      // ignore
    }
    return;
  }
  const head = await SecureStore.getItemAsync(PREFIX + key);
  await SecureStore.deleteItemAsync(PREFIX + key);
  if (head?.startsWith("CHUNKED:")) {
    const count = Number(head.slice("CHUNKED:".length));
    for (let i = 0; i < count; i += 1) {
      await SecureStore.deleteItemAsync(`${PREFIX}${key}__${i}`).catch(() => {});
    }
  }
}

export async function loadSecureJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await getRaw(key);
    if (raw == null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function saveSecureJson<T>(key: string, value: T): Promise<void> {
  try {
    await setRaw(key, JSON.stringify(value));
  } catch {
    // ignore write failures
  }
}

export async function deleteSecureKey(key: string): Promise<void> {
  await deleteRaw(key);
}

export function isHardwareBacked(): boolean {
  return Platform.OS !== "web";
}
