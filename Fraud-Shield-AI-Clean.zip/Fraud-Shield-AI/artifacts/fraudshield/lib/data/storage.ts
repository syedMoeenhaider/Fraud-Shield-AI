// Lightweight wrapper around AsyncStorage for typed JSON persistence.
import AsyncStorage from "@react-native-async-storage/async-storage";

export async function loadJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw == null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function saveJson<T>(key: string, value: T): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Swallow write errors silently in the demo app.
  }
}

// Mock encryption — XOR with a key. NOT real cryptography; for demo only.
const VAULT_KEY = "fr@udshi3ld-d3mo-k3y";

export function mockEncrypt(plain: string): string {
  let out = "";
  for (let i = 0; i < plain.length; i += 1) {
    out += String.fromCharCode(
      plain.charCodeAt(i) ^ VAULT_KEY.charCodeAt(i % VAULT_KEY.length),
    );
  }
  // base64-encode the result so it stores cleanly.
  return btoa(unescape(encodeURIComponent(out)));
}

export function mockDecrypt(cipher: string): string {
  const raw = decodeURIComponent(escape(atob(cipher)));
  let out = "";
  for (let i = 0; i < raw.length; i += 1) {
    out += String.fromCharCode(
      raw.charCodeAt(i) ^ VAULT_KEY.charCodeAt(i % VAULT_KEY.length),
    );
  }
  return out;
}
