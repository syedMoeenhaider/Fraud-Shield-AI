// Mock dataset for the FraudShield AI demo.
// In a production app, these would come from real banking/messaging APIs.

export type Transaction = {
  id: string;
  merchant: string;
  amount: number;
  currency: string;
  category: string;
  device: string;
  location: string;
  timestamp: number;
};

export type Message = {
  id: string;
  sender: string;
  body: string;
  timestamp: number;
};

export type VaultItem = {
  id: string;
  label: string;
  type: "card" | "password" | "id" | "note";
  value: string;
  updatedAt: number;
};

const now = Date.now();
const minutes = (n: number) => n * 60_000;
const hours = (n: number) => n * 60 * 60_000;

export const SEED_TRANSACTIONS: Transaction[] = [
  {
    id: "t1",
    merchant: "Foodpanda",
    amount: 1450,
    currency: "PKR",
    category: "Food",
    device: "iPhone 15 Pro",
    location: "Karachi, PK",
    timestamp: now - minutes(8),
  },
  {
    id: "t2",
    merchant: "Careem Ride",
    amount: 620,
    currency: "PKR",
    category: "Travel",
    device: "iPhone 15 Pro",
    location: "Karachi, PK",
    timestamp: now - hours(2),
  },
  {
    id: "t3",
    merchant: "Daraz",
    amount: 8990,
    currency: "PKR",
    category: "Shopping",
    device: "iPhone 15 Pro",
    location: "Karachi, PK",
    timestamp: now - hours(5),
  },
  {
    id: "t4",
    merchant: "Unknown Merchant",
    amount: 285000,
    currency: "PKR",
    category: "Wire Transfer",
    device: "Unknown Android",
    location: "Lagos, NG",
    timestamp: now - hours(7),
  },
  {
    id: "t5",
    merchant: "Netflix",
    amount: 1100,
    currency: "PKR",
    category: "Entertainment",
    device: "iPhone 15 Pro",
    location: "Karachi, PK",
    timestamp: now - hours(26),
  },
  {
    id: "t6",
    merchant: "Crypto Exchange",
    amount: 124500,
    currency: "PKR",
    category: "Crypto",
    device: "Web Browser",
    location: "Moscow, RU",
    timestamp: now - hours(38),
  },
  {
    id: "t7",
    merchant: "K-Electric",
    amount: 7400,
    currency: "PKR",
    category: "Utilities",
    device: "iPhone 15 Pro",
    location: "Karachi, PK",
    timestamp: now - hours(50),
  },
];

export const SEED_MESSAGES: Message[] = [
  {
    id: "m1",
    sender: "HBL-BANK",
    body: "Your account has been blocked. Click http://hbl-secure-verify.com to reactivate immediately. Share OTP with our agent.",
    timestamp: now - minutes(4),
  },
  {
    id: "m2",
    sender: "+92-300-1234567",
    body: "URGENT: You have won 500,000 PKR in our lucky draw. Click link to claim your prize now: http://win-bigprize.tk",
    timestamp: now - minutes(35),
  },
  {
    id: "m3",
    sender: "Mom",
    body: "Hi beta, dinner is at 8 today. Don't be late!",
    timestamp: now - hours(1),
  },
  {
    id: "m4",
    sender: "JAZZCASH",
    body: "You have received PKR 2,000 from Ahmed Khan. Available balance PKR 18,420.",
    timestamp: now - hours(2),
  },
  {
    id: "m5",
    sender: "EASYPAISA",
    body: "Dear customer, your account requires verification. Send your OTP and PIN to confirm your identity.",
    timestamp: now - hours(3),
  },
  {
    id: "m6",
    sender: "Daraz",
    body: "Your order #DR-19284 has been shipped and will arrive tomorrow.",
    timestamp: now - hours(4),
  },
  {
    id: "m7",
    sender: "+1-415-555-0199",
    body: "Click here to verify your bank password before account is suspended: bit.ly/secure-acc",
    timestamp: now - hours(6),
  },
  {
    id: "m8",
    sender: "Careem",
    body: "Your driver Imran is arriving in 3 minutes. Toyota Corolla, ABC-123.",
    timestamp: now - hours(7),
  },
];

export const SEED_VAULT: VaultItem[] = [
  {
    id: "v1",
    label: "HBL Debit Card",
    type: "card",
    value: "4923-78XX-XXXX-1184",
    updatedAt: now - hours(72),
  },
  {
    id: "v2",
    label: "Online Banking PIN",
    type: "password",
    value: "••••••",
    updatedAt: now - hours(120),
  },
  {
    id: "v3",
    label: "CNIC",
    type: "id",
    value: "42101-XXXXXXX-7",
    updatedAt: now - hours(240),
  },
];

export const SAMPLE_LINKS: { url: string; description: string }[] = [
  { url: "https://hbl-secure-verify.com", description: "Phishing example" },
  { url: "https://www.google.com", description: "Trusted search engine" },
  { url: "http://bit.ly/free-money", description: "Suspicious shortener" },
  { url: "https://www.statebankofpakistan.org.pk", description: "Government" },
];
