// Real biometric wrapper around expo-local-authentication.
// On web (no biometric hardware), we transparently fall back to a simple
// confirmation so the demo still flows on a desktop browser.
import * as LocalAuth from "expo-local-authentication";
import { Platform } from "react-native";

export type BiometricKind = "face" | "fingerprint" | "iris" | "passcode" | "none";

export type BiometricCapability = {
  available: boolean;
  enrolled: boolean;
  kinds: BiometricKind[];
  /** Human-readable label for the primary biometric on this device. */
  primaryLabel: string;
};

export async function getBiometricCapability(): Promise<BiometricCapability> {
  if (Platform.OS === "web") {
    return {
      available: false,
      enrolled: false,
      kinds: [],
      primaryLabel: "Browser confirm",
    };
  }
  try {
    const [hasHw, isEnrolled, types] = await Promise.all([
      LocalAuth.hasHardwareAsync(),
      LocalAuth.isEnrolledAsync(),
      LocalAuth.supportedAuthenticationTypesAsync(),
    ]);
    const kinds: BiometricKind[] = types.map((t) => {
      switch (t) {
        case LocalAuth.AuthenticationType.FACIAL_RECOGNITION:
          return "face";
        case LocalAuth.AuthenticationType.FINGERPRINT:
          return "fingerprint";
        case LocalAuth.AuthenticationType.IRIS:
          return "iris";
        default:
          return "passcode";
      }
    });
    const primaryLabel =
      kinds[0] === "face"
        ? Platform.OS === "ios"
          ? "Face ID"
          : "Face Unlock"
        : kinds[0] === "fingerprint"
          ? Platform.OS === "ios"
            ? "Touch ID"
            : "Fingerprint"
          : kinds[0] === "iris"
            ? "Iris"
            : "Device passcode";
    return {
      available: hasHw,
      enrolled: isEnrolled,
      kinds,
      primaryLabel,
    };
  } catch {
    return {
      available: false,
      enrolled: false,
      kinds: [],
      primaryLabel: "Device passcode",
    };
  }
}

export async function authenticate(promptMessage: string): Promise<{
  success: boolean;
  error?: string;
}> {
  if (Platform.OS === "web") {
    // No biometric on web — use a plain confirm so the user can still see the vault.
    const ok =
      typeof globalThis.confirm === "function"
        ? globalThis.confirm(`${promptMessage}\n\n(Browser fallback — biometric is only available on a real device.)`)
        : true;
    return ok ? { success: true } : { success: false, error: "cancelled" };
  }
  try {
    const cap = await getBiometricCapability();
    const result = await LocalAuth.authenticateAsync({
      promptMessage,
      cancelLabel: "Cancel",
      // If biometrics aren't enrolled, this lets the device PIN/passcode unlock.
      disableDeviceFallback: false,
      fallbackLabel: cap.enrolled ? "Use passcode" : "Use device passcode",
    });
    if (result.success) return { success: true };
    return {
      success: false,
      error: "error" in result ? (result.error ?? "failed") : "failed",
    };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "unknown",
    };
  }
}
