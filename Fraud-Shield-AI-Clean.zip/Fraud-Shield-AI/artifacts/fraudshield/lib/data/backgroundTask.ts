// Background Task — equivalent to WorkManager in Android.
// Uses expo-task-manager + expo-background-fetch to run periodic
// re-analysis even when the app is in the background or closed.
//
// NOTE: Background fetch is limited by the OS:
//   • Android: ~15 min minimum interval (exact timing is OS-controlled)
//   • iOS: ~15 min minimum, OS decides actual frequency based on battery/usage
//   • Web: not supported

import * as BackgroundFetch from "expo-background-fetch";
import * as TaskManager from "expo-task-manager";
import { Platform } from "react-native";

export const BACKGROUND_TASK_NAME = "fraudshield-background-scan";

// ---------- Task definition ----------
// This must be defined at the TOP LEVEL of a module (not inside a function),
// so the JS engine can find it when the task wakes the app.
TaskManager.defineTask(BACKGROUND_TASK_NAME, async () => {
  try {
    // In a full native app you would: read the inbox, call the AI API,
    // and fire a notification here. In managed Expo we can at minimum
    // perform network checks on any queued items persisted to AsyncStorage.
    //
    // For now this acts as a heartbeat that keeps the registration alive
    // and can be extended with AsyncStorage-queued message checks.
    console.log("[FraudShield] Background task fired at", new Date().toISOString());
    return BackgroundFetch.BackgroundFetchResult.NewData;
  } catch {
    return BackgroundFetch.BackgroundFetchResult.Failed;
  }
});

// ---------- Register / unregister ----------

/**
 * Register the background fetch task. Safe to call multiple times.
 */
export async function registerBackgroundTask(): Promise<void> {
  if (Platform.OS === "web") return;

  try {
    const status = await BackgroundFetch.getStatusAsync();

    if (
      status === BackgroundFetch.BackgroundFetchStatus.Restricted ||
      status === BackgroundFetch.BackgroundFetchStatus.Denied
    ) {
      console.warn("[FraudShield] Background fetch is restricted by the OS.");
      return;
    }

    const isRegistered = await TaskManager.isTaskRegisteredAsync(
      BACKGROUND_TASK_NAME,
    );

    if (!isRegistered) {
      await BackgroundFetch.registerTaskAsync(BACKGROUND_TASK_NAME, {
        minimumInterval: 15 * 60, // 15 minutes in seconds
        stopOnTerminate: false,   // keep running after app is closed (Android)
        startOnBoot: true,        // restart after device reboots (Android)
      });
      console.log("[FraudShield] Background task registered.");
    }
  } catch (err) {
    // Silently fail — background fetch is a best-effort feature.
    console.warn("[FraudShield] Could not register background task:", err);
  }
}

/**
 * Unregister the background task (e.g. user disables the feature in settings).
 */
export async function unregisterBackgroundTask(): Promise<void> {
  if (Platform.OS === "web") return;
  try {
    const isRegistered = await TaskManager.isTaskRegisteredAsync(
      BACKGROUND_TASK_NAME,
    );
    if (isRegistered) {
      await BackgroundFetch.unregisterTaskAsync(BACKGROUND_TASK_NAME);
    }
  } catch {
    // ignore
  }
}

/**
 * Returns true if the background task is currently registered.
 */
export async function isBackgroundTaskActive(): Promise<boolean> {
  if (Platform.OS === "web") return false;
  try {
    return await TaskManager.isTaskRegisteredAsync(BACKGROUND_TASK_NAME);
  } catch {
    return false;
  }
}
