// NotificationHelper — handles permission requests, channel setup, and
// sending fraud-verdict notifications via expo-notifications.
// Equivalent to NotificationHelper.java in a native Android project.

import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

// ---------- Channel IDs ----------
export const CHANNEL_FRAUD_ALERT = "fraud-alert";
export const CHANNEL_SAFE = "fraud-safe";

// ---------- One-time setup ----------
// Call this once on app startup.
export async function setupNotifications(): Promise<void> {
  // Configure how notifications appear while the app is in the foreground.
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });

  // Android: create notification channels (required on Android 8+).
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync(CHANNEL_FRAUD_ALERT, {
      name: "Fraud Alerts",
      importance: Notifications.AndroidImportance.MAX,
      sound: "default",
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF0000",
      lockscreenVisibility:
        Notifications.AndroidNotificationVisibility.PUBLIC,
      bypassDnd: true,
    });

    await Notifications.setNotificationChannelAsync(CHANNEL_SAFE, {
      name: "Safe Messages",
      importance: Notifications.AndroidImportance.DEFAULT,
      sound: "default",
    });
  }
}

// ---------- Permission request ----------
// Returns true if permission was granted.
export async function requestNotificationPermission(): Promise<boolean> {
  // Web does not support expo-notifications.
  if (Platform.OS === "web") return false;

  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === "granted") return true;

  const { status } = await Notifications.requestPermissionsAsync({
    ios: {
      allowAlert: true,
      allowBadge: true,
      allowSound: true,
      allowCriticalAlerts: true,
    },
  });
  return status === "granted";
}

// ---------- Notification payloads ----------

type VerdictKind = "danger" | "suspicious" | "safe";

/**
 * Show a high-priority fraud alert notification after AI analysis.
 * Mirrors the Android "⚠️ Fraud Alert" / "✅ Safe Message" pattern.
 */
export async function showVerdictNotification(args: {
  verdict: VerdictKind;
  sender: string;
  summary: string;
  riskScore: number;
}): Promise<void> {
  if (Platform.OS === "web") return;

  const { verdict, sender, summary, riskScore } = args;

  const isFraud = verdict === "danger" || verdict === "suspicious";

  const title = isFraud
    ? verdict === "danger"
      ? `⚠️ Fraud Alert — ${sender}`
      : `🟡 Suspicious — ${sender}`
    : `✅ Safe Message — ${sender}`;

  const body = `${summary} (Risk: ${riskScore}/100)`;

  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: "default",
      priority: isFraud
        ? Notifications.AndroidNotificationPriority.MAX
        : Notifications.AndroidNotificationPriority.DEFAULT,
      color: isFraud ? "#EF4444" : "#22C55E",
      // Android channel
      ...(Platform.OS === "android" && {
        channelId: isFraud ? CHANNEL_FRAUD_ALERT : CHANNEL_SAFE,
      }),
      data: { verdict, sender, riskScore },
    },
    trigger: null, // fire immediately
  });
}

/**
 * Show a URL-specific phishing alert.
 */
export async function showUrlAlert(args: {
  url: string;
  verdict: VerdictKind;
  riskScore: number;
}): Promise<void> {
  if (Platform.OS === "web") return;

  const { url, verdict, riskScore } = args;
  const isFraud = verdict !== "safe";

  await Notifications.scheduleNotificationAsync({
    content: {
      title: isFraud ? `⚠️ Dangerous Link Detected` : `✅ Link Appears Safe`,
      body: `${url.slice(0, 60)}… — Risk score ${riskScore}/100`,
      sound: "default",
      priority: isFraud
        ? Notifications.AndroidNotificationPriority.MAX
        : Notifications.AndroidNotificationPriority.DEFAULT,
      color: isFraud ? "#EF4444" : "#22C55E",
      ...(Platform.OS === "android" && {
        channelId: isFraud ? CHANNEL_FRAUD_ALERT : CHANNEL_SAFE,
      }),
      data: { url, verdict, riskScore },
    },
    trigger: null,
  });
}
