// Calls the api-server's /api/ai/analyze endpoint to get an LLM-powered verdict.
import Constants from "expo-constants";
import { Platform } from "react-native";

import type { Locale } from "@/lib/presentation/i18n";

export type AiVerdict = {
  verdict: "safe" | "suspicious" | "danger";
  riskScore: number;
  summary: string;
  reasons: string[];
  recommendation: string;
};

function getApiBase(): string {
  // On the web, the api-server is mounted on the same host under /api.
  if (Platform.OS === "web") return "/api";

  // Replit exposes the public domain via EXPO_PUBLIC_DOMAIN (set in package.json `dev`).
  const domain =
    process.env.EXPO_PUBLIC_DOMAIN ||
    Constants.expoConfig?.extra?.replitDomain ||
    "";
  if (domain) {
    const host = domain.startsWith("http") ? domain : `https://${domain}`;
    return `${host.replace(/\/$/, "")}/api`;
  }

  // Fallback: assume same-origin (works in some Expo Go/web hybrids).
  return "/api";
}

export async function analyzeWithAi(args: {
  kind: "sms" | "link";
  content: string;
  locale: Locale;
  signal?: AbortSignal;
}): Promise<AiVerdict> {
  const url = `${getApiBase()}/ai/analyze`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      kind: args.kind,
      content: args.content,
      locale: args.locale,
    }),
    signal: args.signal,
  });

  if (!res.ok) {
    // The server returns the fallback shape even on 502, so try to read it.
    const data = (await res.json().catch(() => null)) as
      | (AiVerdict & { error?: string })
      | null;
    if (data && typeof data.verdict === "string") return data;
    throw new Error(`AI analysis failed (${res.status})`);
  }

  return (await res.json()) as AiVerdict;
}
