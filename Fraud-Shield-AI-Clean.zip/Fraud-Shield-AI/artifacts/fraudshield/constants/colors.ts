const colors = {
  light: {
    text: "#0A1628",
    tint: "#00B8A9",

    background: "#F4F7FB",
    foreground: "#0A1628",

    card: "#FFFFFF",
    cardForeground: "#0A1628",

    surface: "#FFFFFF",
    surfaceAlt: "#EEF2F8",

    primary: "#0A1628",
    primaryForeground: "#FFFFFF",

    accent: "#00B8A9",
    accentForeground: "#FFFFFF",

    secondary: "#EEF2F8",
    secondaryForeground: "#0A1628",

    muted: "#EEF2F8",
    mutedForeground: "#64748B",

    border: "#E2E8F0",
    input: "#E2E8F0",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    success: "#10B981",
    warning: "#F59E0B",
    danger: "#EF4444",

    gradientStart: "#0F2942",
    gradientEnd: "#1B4965",
    accentGradientStart: "#00B8A9",
    accentGradientEnd: "#0EA5E9",
    dangerGradientStart: "#EF4444",
    dangerGradientEnd: "#B91C1C",

    glass: "rgba(255,255,255,0.65)",
    glassBorder: "rgba(255,255,255,0.4)",
  },
  dark: {
    text: "#F4F7FB",
    tint: "#00E5D1",

    background: "#05060A",
    foreground: "#F4F7FB",

    card: "#0F141C",
    cardForeground: "#F4F7FB",

    surface: "#0F141C",
    surfaceAlt: "#161C26",

    primary: "#00E5D1",
    primaryForeground: "#05060A",

    accent: "#00E5D1",
    accentForeground: "#05060A",

    secondary: "#161C26",
    secondaryForeground: "#F4F7FB",

    muted: "#161C26",
    mutedForeground: "#8B97AB",

    border: "#1F2733",
    input: "#1F2733",

    destructive: "#FF4D6D",
    destructiveForeground: "#FFFFFF",

    success: "#34D399",
    warning: "#FBBF24",
    danger: "#FF4D6D",

    gradientStart: "#0A1628",
    gradientEnd: "#1B2A41",
    accentGradientStart: "#00E5D1",
    accentGradientEnd: "#22D3EE",
    dangerGradientStart: "#FF4D6D",
    dangerGradientEnd: "#7F1D1D",

    glass: "rgba(15,20,28,0.55)",
    glassBorder: "rgba(255,255,255,0.08)",
  },
  radius: 18,
};

export default colors;
