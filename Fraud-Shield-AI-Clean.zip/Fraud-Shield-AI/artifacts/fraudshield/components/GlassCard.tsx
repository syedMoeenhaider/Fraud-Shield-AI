// Reusable glassmorphism card with optional blur background.
import { BlurView } from "expo-blur";
import React from "react";
import { Platform, StyleSheet, View, ViewStyle } from "react-native";

import { useTheme } from "@/lib/presentation/theme";

type Props = {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  intensity?: number;
  padding?: number;
};

export function GlassCard({ children, style, intensity = 40, padding = 18 }: Props) {
  const { colors, isDark } = useTheme();
  const useBlur = Platform.OS === "ios";

  if (useBlur) {
    return (
      <BlurView
        intensity={intensity}
        tint={isDark ? "dark" : "light"}
        style={[
          styles.base,
          {
            borderRadius: colors.radius,
            borderColor: colors.glassBorder,
            padding,
          },
          style,
        ]}
      >
        {children}
      </BlurView>
    );
  }

  return (
    <View
      style={[
        styles.base,
        {
          borderRadius: colors.radius,
          borderColor: colors.border,
          backgroundColor: colors.card,
          padding,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    overflow: "hidden",
    borderWidth: 1,
  },
});
