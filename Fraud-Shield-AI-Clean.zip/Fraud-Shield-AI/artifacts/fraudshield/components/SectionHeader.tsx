import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { useTheme } from "@/lib/presentation/theme";

type Props = {
  title: string;
  action?: { label: string; onPress: () => void };
};

export function SectionHeader({ title, action }: Props) {
  const { colors } = useTheme();
  return (
    <View style={styles.row}>
      <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
      {action ? (
        <Pressable onPress={action.onPress} hitSlop={10}>
          <Text style={[styles.link, { color: colors.accent }]}>
            {action.label}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 28,
    marginBottom: 12,
  },
  title: { fontFamily: "Inter_700Bold", fontSize: 18, letterSpacing: -0.3 },
  link: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
});
