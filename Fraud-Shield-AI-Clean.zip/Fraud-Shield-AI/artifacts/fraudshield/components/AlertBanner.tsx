// Top alert banner with subtle animated entrance.
import { Feather } from "@expo/vector-icons";
import React, { useEffect } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from "react-native-reanimated";

import { useTheme } from "@/lib/presentation/theme";

type Variant = "danger" | "info" | "success";

export function AlertBanner({
  title,
  description,
  variant = "info",
}: {
  title: string;
  description?: string;
  variant?: Variant;
}) {
  const { colors } = useTheme();
  const pulse = useSharedValue(1);

  useEffect(() => {
    if (variant === "danger") {
      pulse.value = withRepeat(
        withSequence(
          withTiming(1.04, { duration: 600 }),
          withTiming(1, { duration: 600 }),
        ),
        -1,
        true,
      );
    } else {
      pulse.value = 1;
    }
  }, [variant, pulse]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  const accent =
    variant === "danger"
      ? colors.danger
      : variant === "success"
        ? colors.success
        : colors.accent;

  const icon =
    variant === "danger"
      ? "alert-triangle"
      : variant === "success"
        ? "shield"
        : "info";

  return (
    <View
      style={[
        styles.wrap,
        {
          borderColor: accent + "44",
          backgroundColor: accent + "12",
          borderRadius: colors.radius,
        },
      ]}
    >
      <Animated.View
        style={[
          styles.iconWrap,
          { backgroundColor: accent, borderRadius: 14 },
          animStyle,
        ]}
      >
        <Feather name={icon} size={18} color="#fff" />
      </Animated.View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          {title}
        </Text>
        {description ? (
          <Text style={[styles.desc, { color: colors.mutedForeground }]}>
            {description}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    padding: 14,
    borderWidth: 1,
  },
  iconWrap: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  title: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  desc: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
});
