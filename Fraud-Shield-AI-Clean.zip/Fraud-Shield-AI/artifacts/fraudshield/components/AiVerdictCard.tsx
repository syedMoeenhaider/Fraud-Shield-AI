// Renders the LLM analysis result with a gradient header and reason list.
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { ActivityIndicator, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn, FadeInUp } from "react-native-reanimated";

import type { AiVerdict } from "@/lib/data/aiClient";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

type Props = {
  loading: boolean;
  error?: string | null;
  verdict?: AiVerdict | null;
};

export function AiVerdictCard({ loading, error, verdict }: Props) {
  const { colors } = useTheme();
  const { locale } = useI18n();

  if (loading) {
    return (
      <View
        style={[
          styles.loading,
          {
            backgroundColor: colors.surface,
            borderColor: colors.border,
            borderRadius: colors.radius,
          },
        ]}
      >
        <ActivityIndicator color={colors.accent} />
        <Text style={[styles.loadingText, { color: colors.foreground }]}>
          {locale === "ur"
            ? "اے آئی تجزیہ کر رہا ہے…"
            : "AI is analyzing in real time…"}
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View
        style={[
          styles.error,
          {
            backgroundColor: colors.danger + "12",
            borderColor: colors.danger + "55",
            borderRadius: colors.radius,
          },
        ]}
      >
        <Feather name="alert-circle" size={18} color={colors.danger} />
        <Text style={[styles.errorText, { color: colors.danger }]}>
          {error}
        </Text>
      </View>
    );
  }

  if (!verdict) return null;

  const accent =
    verdict.verdict === "danger"
      ? colors.danger
      : verdict.verdict === "suspicious"
        ? colors.warning
        : colors.success;

  const icon =
    verdict.verdict === "danger"
      ? "alert-octagon"
      : verdict.verdict === "suspicious"
        ? "alert-triangle"
        : "shield";

  const title =
    locale === "ur"
      ? verdict.verdict === "danger"
        ? "خطرناک"
        : verdict.verdict === "suspicious"
          ? "مشکوک"
          : "محفوظ"
      : verdict.verdict === "danger"
        ? "Dangerous"
        : verdict.verdict === "suspicious"
          ? "Suspicious"
          : "Safe";

  return (
    <Animated.View entering={FadeInUp.duration(400)}>
      <LinearGradient
        colors={[accent, accent + "BB"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.card, { borderRadius: colors.radius }]}
      >
        <View style={styles.headerRow}>
          <View style={styles.aiBadge}>
            <Feather name="cpu" size={11} color="#fff" />
            <Text style={styles.aiBadgeText}>LIVE AI</Text>
          </View>
          <View style={styles.scorePill}>
            <Text style={styles.scoreValue}>{verdict.riskScore}</Text>
            <Text style={styles.scoreLabel}>/100</Text>
          </View>
        </View>

        <View style={styles.titleRow}>
          <Feather name={icon} size={26} color="#fff" />
          <Text style={styles.title}>{title}</Text>
        </View>

        <Text style={styles.summary}>{verdict.summary}</Text>
      </LinearGradient>

      {verdict.reasons.length > 0 ? (
        <View style={{ gap: 8, marginTop: 12 }}>
          {verdict.reasons.map((r, i) => (
            <Animated.View
              key={i}
              entering={FadeIn.delay(i * 70)}
              style={[
                styles.reasonRow,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View
                style={[
                  styles.reasonDot,
                  { backgroundColor: accent },
                ]}
              />
              <Text
                style={[styles.reasonText, { color: colors.foreground }]}
              >
                {r}
              </Text>
            </Animated.View>
          ))}
        </View>
      ) : null}

      {verdict.recommendation ? (
        <View
          style={[
            styles.tip,
            {
              backgroundColor: accent + "12",
              borderColor: accent + "55",
              borderRadius: colors.radius,
            },
          ]}
        >
          <Feather name="info" size={14} color={accent} />
          <Text style={[styles.tipText, { color: colors.foreground }]}>
            {verdict.recommendation}
          </Text>
        </View>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  loading: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 16,
    borderWidth: 1,
  },
  loadingText: { fontFamily: "Inter_500Medium", fontSize: 13 },
  error: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
    borderWidth: 1,
  },
  errorText: { fontFamily: "Inter_500Medium", fontSize: 13, flex: 1 },
  card: { padding: 18, gap: 12 },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  aiBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "rgba(0,0,0,0.22)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  aiBadgeText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 9,
    letterSpacing: 0.8,
  },
  scorePill: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: 2,
    backgroundColor: "rgba(0,0,0,0.22)",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  scoreValue: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
  scoreLabel: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_500Medium",
    fontSize: 11,
  },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  title: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 24,
    letterSpacing: -0.4,
  },
  summary: {
    color: "rgba(255,255,255,0.95)",
    fontFamily: "Inter_500Medium",
    fontSize: 14,
    lineHeight: 20,
  },
  reasonRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 12,
    borderWidth: 1,
  },
  reasonDot: { width: 8, height: 8, borderRadius: 4, marginTop: 6 },
  reasonText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13, lineHeight: 18 },
  tip: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 12,
    borderWidth: 1,
    marginTop: 12,
  },
  tipText: { flex: 1, fontFamily: "Inter_500Medium", fontSize: 13 },
});
