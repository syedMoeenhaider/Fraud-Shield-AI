// Grid tile used on the dashboard for quick navigation.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { Platform, Pressable, StyleSheet, Text } from "react-native";

import { useTheme } from "@/lib/presentation/theme";

type Props = {
  label: string;
  icon: keyof typeof Feather.glyphMap;
  onPress: () => void;
  tone?: "accent" | "neutral" | "danger";
};

export function QuickAction({ label, icon, onPress, tone = "neutral" }: Props) {
  const { colors } = useTheme();

  const tint =
    tone === "danger"
      ? [colors.dangerGradientStart, colors.dangerGradientEnd]
      : tone === "accent"
        ? [colors.accentGradientStart, colors.accentGradientEnd]
        : [colors.surface, colors.surface];

  const fg =
    tone === "neutral" ? colors.foreground : "#FFFFFF";

  return (
    <Pressable
      onPress={() => {
        if (Platform.OS !== "web") {
          Haptics.selectionAsync().catch(() => {});
        }
        onPress();
      }}
      style={({ pressed }) => [
        styles.wrap,
        { transform: [{ scale: pressed ? 0.97 : 1 }] },
      ]}
    >
      <LinearGradient
        colors={tint as [string, string]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.inner,
          {
            borderRadius: colors.radius,
            borderColor: tone === "neutral" ? colors.border : "transparent",
            borderWidth: tone === "neutral" ? 1 : 0,
          },
        ]}
      >
        <Feather name={icon} size={22} color={fg} />
        <Text style={[styles.label, { color: fg }]}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  inner: {
    paddingVertical: 18,
    paddingHorizontal: 14,
    alignItems: "flex-start",
    gap: 10,
    minHeight: 96,
    justifyContent: "space-between",
  },
  label: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
});
