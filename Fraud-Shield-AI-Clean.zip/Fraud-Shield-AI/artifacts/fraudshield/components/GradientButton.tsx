// Primary call-to-action with a soft fintech gradient + press feedback.
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  ViewStyle,
} from "react-native";

import { useTheme } from "@/lib/presentation/theme";

type Variant = "primary" | "danger" | "ghost";

type Props = {
  label: string;
  onPress: () => void;
  variant?: Variant;
  icon?: React.ReactNode;
  disabled?: boolean;
  style?: ViewStyle;
};

export function GradientButton({
  label,
  onPress,
  variant = "primary",
  icon,
  disabled,
  style,
}: Props) {
  const { colors } = useTheme();

  const gradient =
    variant === "danger"
      ? [colors.dangerGradientStart, colors.dangerGradientEnd]
      : variant === "ghost"
        ? [colors.surfaceAlt, colors.surfaceAlt]
        : [colors.accentGradientStart, colors.accentGradientEnd];

  const textColor =
    variant === "ghost" ? colors.foreground : "#FFFFFF";

  return (
    <Pressable
      onPress={() => {
        if (Platform.OS !== "web") {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
        }
        onPress();
      }}
      disabled={disabled}
      style={({ pressed }) => [
        {
          borderRadius: colors.radius,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
        },
        style,
      ]}
    >
      <LinearGradient
        colors={gradient as [string, string]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.btn, { borderRadius: colors.radius }]}
      >
        {icon}
        <Text style={[styles.label, { color: textColor }]}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    paddingVertical: 16,
    paddingHorizontal: 22,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  label: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 15,
    letterSpacing: 0.2,
  },
});
