// MessageItem — renders a single SMS with heuristic verdict and expandable
// live AI analysis. Pass autoAnalyze={true} for newly added real messages
// so analysis fires immediately without requiring a user tap.
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useState } from "react";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";

import { AiVerdictCard } from "@/components/AiVerdictCard";
import { analyzeWithAi, type AiVerdict } from "@/lib/data/aiClient";
import {
  showUrlAlert,
  showVerdictNotification,
} from "@/lib/data/notificationHelper";
import type { Message } from "@/lib/data/mockData";
import { analyzeMessage } from "@/lib/domain/analyzers";
import { extractUrls } from "@/lib/domain/urlExtractor";
import { useI18n } from "@/lib/presentation/i18n";
import { useTheme } from "@/lib/presentation/theme";

function formatTime(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.round(diff / 60_000);
  if (m < 1) return "now";
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.round(h / 24)}d`;
}

type Props = {
  message: Message;
  /** When true, AI analysis starts immediately (used for newly added messages). */
  autoAnalyze?: boolean;
};

export function MessageItem({ message, autoAnalyze = false }: Props) {
  const { colors } = useTheme();
  const { t, locale } = useI18n();
  const verdict = analyzeMessage(message);

  const [expanded, setExpanded] = useState(autoAnalyze);
  const [aiVerdict, setAiVerdict] = useState<AiVerdict | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const accent =
    verdict.risk === "danger"
      ? colors.danger
      : verdict.risk === "suspicious"
        ? colors.warning
        : colors.success;

  const label =
    verdict.risk === "danger"
      ? t.dangerous
      : verdict.risk === "suspicious"
        ? t.suspicious
        : t.safe;

  const icon =
    verdict.risk === "danger"
      ? "alert-octagon"
      : verdict.risk === "suspicious"
        ? "alert-circle"
        : "check-circle";

  // ── Core analysis function ──────────────────────────────────────────────
  const runAi = async () => {
    if (aiVerdict || aiLoading) return;
    setAiLoading(true);
    setAiError(null);

    if (Platform.OS !== "web") {
      Haptics.selectionAsync().catch(() => {});
    }

    try {
      // 1️⃣ Analyze the full SMS body with AI (FraudAnalyzer equivalent).
      const ai = await analyzeWithAi({
        kind: "sms",
        content: `From: ${message.sender}\n${message.body}`,
        locale,
      });
      setAiVerdict(ai);

      // 2️⃣ Send a high-priority notification with the verdict (NotificationHelper equivalent).
      await showVerdictNotification({
        verdict: ai.verdict,
        sender: message.sender,
        summary: ai.summary,
        riskScore: ai.riskScore,
      });

      // 3️⃣ Extract URLs from the SMS and analyze each one separately.
      const urls = extractUrls(message.body);
      for (const u of urls) {
        if (u.isSuspicious) {
          // Fire a separate URL-specific notification for each bad link.
          await showUrlAlert({
            url: u.raw,
            verdict: "danger",
            riskScore: 85,
          });
        }
      }
    } catch (err) {
      setAiError(err instanceof Error ? err.message : "AI analysis failed");
    } finally {
      setAiLoading(false);
    }
  };

  // Auto-trigger AI if the prop is set (new message just added by user).
  useEffect(() => {
    if (autoAnalyze) {
      runAi();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoAnalyze]);

  const onPress = () => {
    setExpanded((e) => {
      const next = !e;
      if (next && !aiVerdict && !aiLoading) runAi();
      return next;
    });
  };

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.row,
        {
          backgroundColor: colors.surface,
          borderColor: accent + "55",
          borderLeftColor: accent,
          borderRadius: colors.radius,
          opacity: pressed ? 0.92 : 1,
        },
      ]}
    >
      {/* ── Header row ── */}
      <View style={styles.header}>
        <View style={styles.left}>
          <View style={[styles.iconWrap, { backgroundColor: accent + "22" }]}>
            <Feather name={icon} size={16} color={accent} />
          </View>
          <View>
            <Text style={[styles.sender, { color: colors.foreground }]}>
              {message.sender}
            </Text>
            <Text style={[styles.time, { color: colors.mutedForeground }]}>
              {formatTime(message.timestamp)}{" "}
              {locale === "ur" ? "پہلے" : "ago"}
            </Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          {/* Auto-analyze badge for newly added messages */}
          {autoAnalyze && aiLoading ? (
            <View
              style={[
                styles.liveBadge,
                { backgroundColor: colors.accent + "22" },
              ]}
            >
              <Feather name="cpu" size={11} color={colors.accent} />
              <Text style={[styles.liveBadgeText, { color: colors.accent }]}>
                SCANNING
              </Text>
            </View>
          ) : null}
          <View style={[styles.pill, { backgroundColor: accent }]}>
            <Text style={styles.pillText}>{label.toUpperCase()}</Text>
          </View>
          <Feather
            name={expanded ? "chevron-up" : "chevron-down"}
            size={16}
            color={colors.mutedForeground}
          />
        </View>
      </View>

      {/* ── Message body ── */}
      <Text style={[styles.body, { color: colors.foreground }]}>
        {message.body}
      </Text>

      {/* ── Heuristic keyword tags ── */}
      {verdict.matchedKeywords.length > 0 ? (
        <View style={styles.tagRow}>
          <Text style={[styles.tagLabel, { color: colors.mutedForeground }]}>
            {t.matched}:
          </Text>
          {verdict.matchedKeywords.map((k) => (
            <View key={k} style={[styles.tag, { backgroundColor: accent + "1F" }]}>
              <Text style={[styles.tagText, { color: accent }]}>{k}</Text>
            </View>
          ))}
        </View>
      ) : null}

      {/* ── URL extraction indicator ── */}
      {verdict.hasLink ? (
        <View style={styles.urlRow}>
          <Feather name="link" size={12} color={colors.warning} />
          <Text style={[styles.urlText, { color: colors.warning }]}>
            {locale === "ur"
              ? "لنک ملا — الگ سے تجزیہ ہو رہا ہے"
              : "URL detected — analyzed separately"}
          </Text>
        </View>
      ) : null}

      {/* ── Tap hint (only when collapsed and not auto-analyzing) ── */}
      {!expanded && !autoAnalyze ? (
        <View style={styles.aiHint}>
          <Feather name="cpu" size={12} color={colors.accent} />
          <Text style={[styles.aiHintText, { color: colors.accent }]}>
            {locale === "ur"
              ? "اے آئی گہرا تجزیہ کے لیے ٹیپ کریں"
              : "Tap for live AI analysis"}
          </Text>
        </View>
      ) : null}

      {/* ── AI verdict card ── */}
      {expanded || autoAnalyze ? (
        <Animated.View entering={FadeIn.duration(220)} style={{ marginTop: 6 }}>
          <AiVerdictCard
            loading={aiLoading}
            error={aiError}
            verdict={aiVerdict}
          />
        </Animated.View>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    padding: 14,
    borderWidth: 1,
    borderLeftWidth: 4,
    gap: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 6 },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  sender: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  time: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 1 },
  pill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  pillText: {
    fontFamily: "Inter_700Bold",
    fontSize: 10,
    color: "#fff",
    letterSpacing: 0.6,
  },
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  liveBadgeText: {
    fontFamily: "Inter_700Bold",
    fontSize: 9,
    letterSpacing: 0.8,
  },
  body: { fontFamily: "Inter_400Regular", fontSize: 14, lineHeight: 20 },
  tagRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    gap: 6,
  },
  tagLabel: { fontFamily: "Inter_500Medium", fontSize: 11, marginRight: 4 },
  tag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999 },
  tagText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  urlRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  urlText: { fontFamily: "Inter_500Medium", fontSize: 11 },
  aiHint: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 },
  aiHintText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
});
