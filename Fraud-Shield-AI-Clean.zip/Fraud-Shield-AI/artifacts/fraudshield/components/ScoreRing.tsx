// Animated SVG progress ring used for the security score.
import React, { useEffect } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, {
  useAnimatedProps,
  useSharedValue,
  withTiming,
  Easing,
} from "react-native-reanimated";
import Svg, { Circle, Defs, LinearGradient, Stop } from "react-native-svg";

import { useTheme } from "@/lib/presentation/theme";

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

type Props = {
  value: number; // 0–100
  size?: number;
  label?: string;
  sublabel?: string;
};

export function ScoreRing({ value, size = 220, label, sublabel }: Props) {
  const { colors } = useTheme();
  const stroke = 14;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;

  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withTiming(Math.max(0, Math.min(100, value)) / 100, {
      duration: 1200,
      easing: Easing.out(Easing.cubic),
    });
  }, [value, progress]);

  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference * (1 - progress.value),
  }));

  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      <Svg width={size} height={size}>
        <Defs>
          <LinearGradient id="grad" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor={colors.accentGradientStart} />
            <Stop offset="1" stopColor={colors.accentGradientEnd} />
          </LinearGradient>
        </Defs>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={colors.surfaceAlt}
          strokeWidth={stroke}
          fill="none"
        />
        <AnimatedCircle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="url(#grad)"
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={`${circumference} ${circumference}`}
          animatedProps={animatedProps}
          rotation="-90"
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
      <View style={styles.inner} pointerEvents="none">
        <Text style={[styles.value, { color: colors.foreground }]}>
          {Math.round(value)}
        </Text>
        {label ? (
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            {label}
          </Text>
        ) : null}
        {sublabel ? (
          <Text style={[styles.sublabel, { color: colors.success }]}>
            {sublabel}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: "center", justifyContent: "center" },
  inner: { position: "absolute", alignItems: "center" },
  value: { fontFamily: "Inter_700Bold", fontSize: 56, letterSpacing: -1 },
  label: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
    marginTop: 4,
    letterSpacing: 0.4,
    textTransform: "uppercase",
  },
  sublabel: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
    marginTop: 6,
  },
});
