// Renders a single transaction with AI risk verdict.
import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

import {
  analyzeTransaction,
  type FraudVerdict,
} from "@/lib/domain/analyzers";
import type { Transaction } from "@/lib/data/mockData";
import { useTheme } from "@/lib/presentation/theme";

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.round(diff / 60_000);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

function badgeColor(v: FraudVerdict, colors: ReturnType<typeof useTheme>["colors"]) {
  if (v.riskScore >= 70) return colors.danger;
  if (v.riskScore >= 40) return colors.warning;
  return colors.success;
}

const CATEGORY_ICON: Record<string, keyof typeof Feather.glyphMap> = {
  Food: "coffee",
  Travel: "navigation",
  Shopping: "shopping-bag",
  "Wire Transfer": "send",
  Entertainment: "film",
  Crypto: "trending-up",
  Utilities: "zap",
};

export function TransactionItem({ tx }: { tx: Transaction }) {
  const { colors } = useTheme();
  const verdict = analyzeTransaction(tx);
  const color = badgeColor(verdict, colors);
  const icon = CATEGORY_ICON[tx.category] ?? "credit-card";

  return (
    <View
      style={[
        styles.row,
        {
          borderColor: colors.border,
          backgroundColor: colors.surface,
          borderRadius: colors.radius,
        },
      ]}
    >
      <View
        style={[
          styles.iconWrap,
          { backgroundColor: color + "22", borderRadius: colors.radius - 4 },
        ]}
      >
        <Feather name={icon} size={20} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.merchant, { color: colors.foreground }]}>
          {tx.merchant}
        </Text>
        <Text style={[styles.meta, { color: colors.mutedForeground }]}>
          {tx.location} · {formatRelative(tx.timestamp)}
        </Text>
        {verdict.riskScore >= 40 ? (
          <View style={[styles.badge, { backgroundColor: color + "1F" }]}>
            <Feather name="alert-triangle" size={11} color={color} />
            <Text style={[styles.badgeText, { color }]}>{verdict.reason}</Text>
          </View>
        ) : null}
      </View>
      <View style={{ alignItems: "flex-end" }}>
        <Text style={[styles.amount, { color: colors.foreground }]}>
          {tx.currency} {tx.amount.toLocaleString()}
        </Text>
        <Text style={[styles.meta, { color: colors.mutedForeground }]}>
          {tx.category}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderWidth: 1,
    gap: 14,
  },
  iconWrap: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  merchant: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  meta: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 2 },
  amount: { fontFamily: "Inter_700Bold", fontSize: 15 },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    marginTop: 6,
    alignSelf: "flex-start",
  },
  badgeText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
});
