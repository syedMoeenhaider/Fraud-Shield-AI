// AI-powered fraud analysis endpoint for FraudShield AI.
// Accepts an SMS body or URL and returns a structured verdict.
import { Router, type IRouter, type Request, type Response } from "express";

import { openai } from "../lib/openai";

const router: IRouter = Router();

type Kind = "sms" | "link";
type Locale = "en" | "ur";

type AnalyzeBody = {
  kind?: Kind;
  content?: string;
  locale?: Locale;
};

type AnalyzeResult = {
  verdict: "safe" | "suspicious" | "danger";
  riskScore: number;
  summary: string;
  reasons: string[];
  recommendation: string;
};

const FALLBACK: AnalyzeResult = {
  verdict: "suspicious",
  riskScore: 50,
  summary: "Unable to fully analyze — proceed with caution.",
  reasons: ["AI analysis was inconclusive."],
  recommendation: "Verify directly with the sender or institution.",
};

function buildPrompt(kind: Kind, content: string, locale: Locale): string {
  const language = locale === "ur" ? "Urdu (اردو)" : "English";
  const target =
    kind === "sms"
      ? "this SMS message a banking customer received"
      : "this URL a banking customer is about to open";

  return [
    `You are FraudShield AI, an expert in detecting financial scams, phishing, and account-takeover attempts.`,
    `Analyze ${target} and decide if it is safe, suspicious, or dangerous.`,
    ``,
    `Respond ONLY with a single JSON object — no markdown, no commentary — using this exact schema:`,
    `{`,
    `  "verdict": "safe" | "suspicious" | "danger",`,
    `  "riskScore": number from 0 to 100,`,
    `  "summary": "one short sentence explaining the verdict",`,
    `  "reasons": ["specific signal 1", "specific signal 2", ...],`,
    `  "recommendation": "one short actionable instruction for the user"`,
    `}`,
    ``,
    `Write the "summary", "reasons", and "recommendation" fields in ${language}.`,
    `Be concrete: cite suspicious words, domains, urgency cues, requests for credentials, etc.`,
    ``,
    `INPUT (${kind}):`,
    content,
  ].join("\n");
}

function parseAiResponse(raw: string): AnalyzeResult {
  // Strip code fences if the model wrapped output in ```json```.
  const cleaned = raw
    .trim()
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  try {
    const parsed = JSON.parse(cleaned) as Partial<AnalyzeResult>;
    const verdict: AnalyzeResult["verdict"] =
      parsed.verdict === "safe" || parsed.verdict === "danger"
        ? parsed.verdict
        : "suspicious";
    const riskScore = Math.max(
      0,
      Math.min(100, Math.round(Number(parsed.riskScore) || 0)),
    );
    const reasons = Array.isArray(parsed.reasons)
      ? parsed.reasons.filter((r): r is string => typeof r === "string")
      : [];
    return {
      verdict,
      riskScore,
      summary: typeof parsed.summary === "string" ? parsed.summary : FALLBACK.summary,
      reasons: reasons.length > 0 ? reasons : FALLBACK.reasons,
      recommendation:
        typeof parsed.recommendation === "string"
          ? parsed.recommendation
          : FALLBACK.recommendation,
    };
  } catch {
    return { ...FALLBACK, summary: cleaned.slice(0, 220) || FALLBACK.summary };
  }
}

router.post("/ai/analyze", async (req: Request, res: Response) => {
  const body = (req.body ?? {}) as AnalyzeBody;
  const kind: Kind = body.kind === "link" ? "link" : "sms";
  const locale: Locale = body.locale === "ur" ? "ur" : "en";
  const content = (body.content ?? "").toString().trim();

  if (!content) {
    return res.status(400).json({ error: "content is required" });
  }
  if (content.length > 2000) {
    return res.status(400).json({ error: "content too long (max 2000 chars)" });
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 1500,
      messages: [
        {
          role: "system",
          content:
            "You are a strict JSON-only fraud detection assistant. Never include explanations outside of the JSON object.",
        },
        { role: "user", content: buildPrompt(kind, content, locale) },
      ],
      response_format: { type: "json_object" },
    });

    const raw = completion.choices[0]?.message?.content ?? "";
    req.log.info(
      { rawLen: raw.length, finishReason: completion.choices[0]?.finish_reason },
      "AI raw response",
    );
    const result = parseAiResponse(raw);
    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "AI analyze failed");
    return res.status(502).json({
      error: "AI analysis temporarily unavailable",
      ...FALLBACK,
    });
  }
});

export default router;
