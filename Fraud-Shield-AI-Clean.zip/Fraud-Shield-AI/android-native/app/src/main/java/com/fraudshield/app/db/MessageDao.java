package com.fraudshield.app.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * MessageDao — Room Data Access Object.
 * All database operations for analyzed messages.
 */
@Dao
public interface MessageDao {

    /** Insert a new analyzed message record. */
    @Insert
    void insert(AnalyzedMessage message);

    /** Get all messages, newest first. LiveData auto-updates the UI. */
    @Query("SELECT * FROM analyzed_messages ORDER BY timestamp DESC")
    LiveData<List<AnalyzedMessage>> getAllMessages();

    /** Get only fraud/suspicious messages. */
    @Query("SELECT * FROM analyzed_messages WHERE verdict != 'safe' ORDER BY timestamp DESC")
    LiveData<List<AnalyzedMessage>> getThreats();

    /** Total number of records. */
    @Query("SELECT COUNT(*) FROM analyzed_messages")
    int getCount();

    /** Delete all records (for clear history button). */
    @Query("DELETE FROM analyzed_messages")
    void deleteAll();

    /** Delete records older than given timestamp. */
    @Query("DELETE FROM analyzed_messages WHERE timestamp < :cutoffMs")
    void deleteOlderThan(long cutoffMs);
}
