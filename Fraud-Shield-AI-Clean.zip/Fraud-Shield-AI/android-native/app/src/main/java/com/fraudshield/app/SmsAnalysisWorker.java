package com.fraudshield.app;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.fraudshield.app.db.AnalyzedMessage;
import com.fraudshield.app.db.AppDatabase;

import java.util.List;

/**
 * SmsAnalysisWorker — WorkManager background worker.
 *
 * Runs on a background thread guaranteed by WorkManager.
 * Steps:
 *   1. Read sender + body from WorkManager input data
 *   2. Send to AI API via FraudAnalyzer (synchronous HTTP call)
 *   3. Extract and analyze any URLs found in the body
 *   4. Show status bar notification via NotificationHelper
 *   5. Save result to Room database for history screen
 */
public class SmsAnalysisWorker extends Worker {

    private static final String TAG = "FraudShield_Worker";

    // Keys for WorkManager input data (must match SMSReceiver).
    public static final String KEY_SENDER = "sender";
    public static final String KEY_BODY   = "body";

    public SmsAnalysisWorker(@NonNull Context context,
                             @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();

        // ── 1. Read input ─────────────────────────────────────────────────
        String sender = getInputData().getString(KEY_SENDER);
        String body   = getInputData().getString(KEY_BODY);

        if (sender == null || body == null || body.trim().isEmpty()) {
            Log.w(TAG, "Empty input data — skipping");
            return Result.failure();
        }

        Log.d(TAG, "Analyzing SMS from: " + sender);

        // ── 2. Analyze full SMS body with AI ──────────────────────────────
        FraudAnalyzer.AiResult smsResult = FraudAnalyzer.analyzeSms(sender, body);

        if (smsResult != null) {
            Log.d(TAG, "AI verdict: " + smsResult.verdict
                    + " | score: " + smsResult.riskScore);

            // ── 3. Show status bar notification ───────────────────────────
            if (smsResult.isThreat()) {
                // ⚠️ Fraud or suspicious — high priority alert
                NotificationHelper.showFraudAlert(
                        context,
                        sender,
                        smsResult.summary,
                        smsResult.riskScore,
                        smsResult.firstReason()
                );
            } else {
                // ✅ Safe message notification
                NotificationHelper.showSafeAlert(
                        context,
                        sender,
                        smsResult.summary,
                        smsResult.riskScore
                );
            }

            // ── 4. Save to database ───────────────────────────────────────
            saveToDatabase(sender, body, smsResult, "sms");
        } else {
            // AI call failed — show a generic alert so the user
            // knows something suspicious arrived and to check manually.
            Log.w(TAG, "AI call failed — showing generic alert");
            NotificationHelper.showFraudAlert(
                    context,
                    sender,
                    "Could not fully analyze this message. Check manually.",
                    50,
                    "AI analysis was unavailable."
            );
        }

        // ── 5. Extract and analyze URLs separately ────────────────────────
        List<String> urls = FraudAnalyzer.extractUrls(body);
        Log.d(TAG, "Found " + urls.size() + " URL(s) in SMS");

        for (String url : urls) {
            Log.d(TAG, "Checking URL: " + url);

            // Quick TLD check first — no network call needed.
            if (FraudAnalyzer.isSuspiciousByTld(url)) {
                // Definitely suspicious — alert without waiting for AI.
                NotificationHelper.showUrlAlert(context, url, 85);
                saveToDatabase(sender, url, null, "link_quick");
                continue;
            }

            // Full AI link analysis for non-obvious URLs.
            FraudAnalyzer.AiResult urlResult = FraudAnalyzer.analyzeUrl(url);
            if (urlResult != null && urlResult.isThreat()) {
                NotificationHelper.showUrlAlert(context, url, urlResult.riskScore);
                saveToDatabase(sender, url, urlResult, "link");
            }
        }

        return Result.success();
    }

    // ── Save result to Room database ─────────────────────────────────────

    private void saveToDatabase(String sender, String content,
                                FraudAnalyzer.AiResult result, String kind) {
        try {
            AnalyzedMessage record = new AnalyzedMessage();
            record.sender    = sender;
            record.content   = content;
            record.kind      = kind;
            record.timestamp = System.currentTimeMillis();

            if (result != null) {
                record.verdict        = result.verdict;
                record.riskScore      = result.riskScore;
                record.summary        = result.summary;
                record.recommendation = result.recommendation;
                record.firstReason    = result.firstReason();
            } else {
                record.verdict   = "suspicious";
                record.riskScore = 50;
                record.summary   = "AI unavailable — review manually";
            }

            AppDatabase.getInstance(getApplicationContext())
                    .messageDao()
                    .insert(record);

        } catch (Exception e) {
            Log.e(TAG, "Failed to save to database: " + e.getMessage());
        }
    }
}
