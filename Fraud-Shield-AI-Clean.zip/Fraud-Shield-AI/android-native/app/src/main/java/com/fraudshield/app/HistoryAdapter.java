package com.fraudshield.app;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fraudshield.app.db.AnalyzedMessage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * HistoryAdapter — RecyclerView adapter for the scan history screen.
 * Each row shows: sender, verdict badge, risk score, summary, timestamp.
 */
public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<AnalyzedMessage> messages = new ArrayList<>();
    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat("dd MMM yyyy  hh:mm a", Locale.getDefault());

    public void setMessages(List<AnalyzedMessage> messages) {
        this.messages = messages != null ? messages : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AnalyzedMessage msg = messages.get(position);

        holder.tvSender.setText(msg.sender != null ? msg.sender : "Unknown");
        holder.tvSummary.setText(msg.summary != null ? msg.summary : "No summary");
        holder.tvScore.setText("Risk: " + msg.riskScore + "/100");
        holder.tvTime.setText(dateFormat.format(new Date(msg.timestamp)));
        holder.tvKind.setText(msg.kind != null ? msg.kind.toUpperCase() : "SMS");

        // Verdict badge color
        String verdict = msg.verdict != null ? msg.verdict : "suspicious";
        switch (verdict) {
            case "danger":
                holder.tvVerdict.setText("⚠️ DANGER");
                holder.tvVerdict.setBackgroundColor(Color.parseColor("#FFEEEE"));
                holder.tvVerdict.setTextColor(Color.parseColor("#CC0000"));
                holder.itemView.setBackgroundColor(Color.parseColor("#FFF5F5"));
                break;
            case "suspicious":
                holder.tvVerdict.setText("🟡 SUSPICIOUS");
                holder.tvVerdict.setBackgroundColor(Color.parseColor("#FFF8E1"));
                holder.tvVerdict.setTextColor(Color.parseColor("#E65100"));
                holder.itemView.setBackgroundColor(Color.parseColor("#FFFDE7"));
                break;
            default:
                holder.tvVerdict.setText("✅ SAFE");
                holder.tvVerdict.setBackgroundColor(Color.parseColor("#E8F5E9"));
                holder.tvVerdict.setTextColor(Color.parseColor("#1B5E20"));
                holder.itemView.setBackgroundColor(Color.WHITE);
                break;
        }

        // Show first reason if available
        if (msg.firstReason != null && !msg.firstReason.isEmpty()) {
            holder.tvReason.setVisibility(View.VISIBLE);
            holder.tvReason.setText("🔍 " + msg.firstReason);
        } else {
            holder.tvReason.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSender, tvVerdict, tvScore, tvSummary,
                 tvReason, tvTime, tvKind;

        ViewHolder(View v) {
            super(v);
            tvSender  = v.findViewById(R.id.tv_sender);
            tvVerdict = v.findViewById(R.id.tv_verdict);
            tvScore   = v.findViewById(R.id.tv_score);
            tvSummary = v.findViewById(R.id.tv_summary);
            tvReason  = v.findViewById(R.id.tv_reason);
            tvTime    = v.findViewById(R.id.tv_time);
            tvKind    = v.findViewById(R.id.tv_kind);
        }
    }
}
