package com.fraudshield.app;

import android.app.Application;
import com.fraudshield.app.NotificationHelper;

/**
 * FraudShieldApp — Application class.
 * Place this in AndroidManifest.xml as android:name=".FraudShieldApp"
 * This runs once when the device boots or the app process starts.
 */
public class FraudShieldApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        // Create notification channels once on startup.
        // Required on Android 8+ or notifications will never show.
        NotificationHelper.createChannels(this);
    }
}
