package com.fraudshield.app.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * AnalyzedMessage — Room database entity.
 * One row per scanned SMS or URL.
 * Table name: analyzed_messages
 */
@Entity(tableName = "analyzed_messages")
public class AnalyzedMessage {

    @PrimaryKey(autoGenerate = true)
    public int id;

    /** SMS sender name or number e.g. "HBL-BANK" */
    public String sender;

    /** Full SMS body or URL that was analyzed */
    public String content;

    /** "sms", "link", or "link_quick" */
    public String kind;

    /** Unix timestamp in milliseconds */
    public long timestamp;

    /** "safe" | "suspicious" | "danger" */
    public String verdict;

    /** 0–100 AI risk score */
    public int riskScore;

    /** One-line AI summary */
    public String summary;

    /** First specific reason from AI */
    public String firstReason;

    /** What the user should do */
    public String recommendation;
}
