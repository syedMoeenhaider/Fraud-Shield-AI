package com.fraudshield.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

/**
 * MainActivity — entry point of the app.
 *
 * Responsibilities:
 *   1. Request all required permissions on first launch
 *   2. Show permission status to the user
 *   3. Keep existing manual input feature (paste SMS / URL and scan)
 *   4. Button to view scan history
 *
 * Automatic detection runs entirely in SMSReceiver + SmsAnalysisWorker
 * and does NOT require this Activity to be open.
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PERMISSIONS = 101;

    // Permissions needed for full auto-detection.
    private static final String[] REQUIRED_PERMISSIONS;

    static {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            REQUIRED_PERMISSIONS = new String[]{
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.POST_NOTIFICATIONS
            };
        } else {
            REQUIRED_PERMISSIONS = new String[]{
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS
            };
        }
    }

    // UI references
    private TextView  tvStatus;
    private EditText  etSender;
    private EditText  etMessage;
    private Button    btnScan;
    private Button    btnHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        tvStatus   = findViewById(R.id.tv_status);
        etSender   = findViewById(R.id.et_sender);
        etMessage  = findViewById(R.id.et_message);
        btnScan    = findViewById(R.id.btn_scan);
        btnHistory = findViewById(R.id.btn_history);

        // Request permissions and update status label.
        requestAllPermissions();

        // Manual scan button — keeps existing feature working.
        btnScan.setOnClickListener(v -> manualScan());

        // Open history screen.
        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));
    }

    // ── Manual scan (existing feature preserved) ──────────────────────────

    private void manualScan() {
        String sender  = etSender.getText().toString().trim();
        String message = etMessage.getText().toString().trim();

        if (message.isEmpty()) {
            Toast.makeText(this, "Please enter a message or URL", Toast.LENGTH_SHORT).show();
            return;
        }

        if (sender.isEmpty()) sender = "Manual Input";

        Toast.makeText(this, "Scanning with AI…", Toast.LENGTH_SHORT).show();

        // Route through the same WorkManager pipeline as auto-detected SMS.
        Data inputData = new Data.Builder()
                .putString(SmsAnalysisWorker.KEY_SENDER, sender)
                .putString(SmsAnalysisWorker.KEY_BODY, message)
                .build();

        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(SmsAnalysisWorker.class)
                .setInputData(inputData)
                .build();

        WorkManager.getInstance(this).enqueue(work);

        // Clear inputs after submitting.
        etSender.setText("");
        etMessage.setText("");

        Toast.makeText(this,
                "Analysis started — you'll get a notification with the result",
                Toast.LENGTH_LONG).show();
    }

    // ── Permission handling ───────────────────────────────────────────────

    private void requestAllPermissions() {
        boolean allGranted = true;
        for (String perm : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, perm)
                    != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }

        if (allGranted) {
            showStatus(true);
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_CODE_PERMISSIONS) return;

        boolean allGranted = true;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        showStatus(allGranted);
    }

    private void showStatus(boolean active) {
        if (active) {
            tvStatus.setText("🟢 Auto-detection ACTIVE — monitoring all incoming SMS");
            tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        } else {
            tvStatus.setText("🔴 Permissions required — tap here to grant SMS & notification access");
            tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
            tvStatus.setOnClickListener(v -> requestAllPermissions());
        }
    }
}
