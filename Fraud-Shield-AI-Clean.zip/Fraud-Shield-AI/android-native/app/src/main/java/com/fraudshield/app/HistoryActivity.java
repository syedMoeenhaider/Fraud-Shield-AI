package com.fraudshield.app;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fraudshield.app.db.AppDatabase;

/**
 * HistoryActivity — shows all previously scanned SMS and URLs.
 * Automatically updates when new scans arrive (LiveData).
 */
public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private TextView tvEmpty;
    private Button btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Enable back button in action bar.
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Scan History");
        }

        recyclerView = findViewById(R.id.recycler_history);
        tvEmpty      = findViewById(R.id.tv_empty);
        btnClear     = findViewById(R.id.btn_clear);

        // Set up RecyclerView with the adapter.
        adapter = new HistoryAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Observe database — list updates automatically when new SMS is scanned.
        AppDatabase.getInstance(this)
                .messageDao()
                .getAllMessages()
                .observe(this, messages -> {
                    adapter.setMessages(messages);
                    if (messages == null || messages.isEmpty()) {
                        tvEmpty.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                });

        // Clear all history.
        btnClear.setOnClickListener(v ->
                new Thread(() ->
                        AppDatabase.getInstance(this).messageDao().deleteAll()
                ).start()
        );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
