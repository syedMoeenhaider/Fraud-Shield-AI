package com.fraudshield.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

/**
 * SMSReceiver — Android BroadcastReceiver that wakes automatically
 * the moment any SMS arrives on the device, even when the app is closed.
 *
 * Flow:
 *   SMS arrives → Android wakes SMSReceiver → extracts sender + body
 *              → hands off to WorkManager → SmsAnalysisWorker calls AI
 *              → NotificationHelper shows status bar alert
 *
 * Registered in AndroidManifest.xml with:
 *   <receiver android:name=".SMSReceiver" android:exported="true">
 *       <intent-filter android:priority="999">
 *           <action android:name="android.provider.Telephony.SMS_RECEIVED"/>
 *       </intent-filter>
 *   </receiver>
 */
public class SMSReceiver extends BroadcastReceiver {

    private static final String TAG = "FraudShield_SMS";
    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";

    @Override
    public void onReceive(Context context, Intent intent) {

        // Safety check — only handle real SMS intents.
        if (intent == null || !SMS_RECEIVED.equals(intent.getAction())) return;

        Bundle bundle = intent.getExtras();
        if (bundle == null) return;

        // Extract PDU objects (raw SMS data packets).
        Object[] pdus = (Object[]) bundle.get("pdus");
        if (pdus == null || pdus.length == 0) return;

        String format       = bundle.getString("format", "3gpp");
        StringBuilder body  = new StringBuilder();
        String sender       = "";

        // Each PDU is one part of the message (long SMS = multiple PDUs).
        for (Object pdu : pdus) {
            SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu, format);
            if (sms != null) {
                sender = sms.getDisplayOriginatingAddress();
                body.append(sms.getMessageBody());
            }
        }

        String messageBody = body.toString().trim();
        if (messageBody.isEmpty()) return;

        Log.d(TAG, "New SMS from: " + sender + " | " + messageBody.length() + " chars");

        // ── Hand off to WorkManager ───────────────────────────────────────
        // WorkManager guarantees this runs even if the device goes to sleep,
        // and automatically retries if the network is temporarily unavailable.
        Data inputData = new Data.Builder()
                .putString(SmsAnalysisWorker.KEY_SENDER, sender)
                .putString(SmsAnalysisWorker.KEY_BODY, messageBody)
                .build();

        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(SmsAnalysisWorker.class)
                .setInputData(inputData)
                .build();

        WorkManager.getInstance(context).enqueue(work);

        Log.d(TAG, "Analysis job queued for WorkManager");
    }
}
