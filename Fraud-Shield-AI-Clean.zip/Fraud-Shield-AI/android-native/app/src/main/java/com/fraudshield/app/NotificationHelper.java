package com.fraudshield.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/**
 * NotificationHelper — handles all status bar notifications.
 *
 * Two channels:
 *   fraudshield_fraud  → MAX priority, red light, bypasses DND
 *   fraudshield_safe   → DEFAULT priority
 *
 * Usage:
 *   NotificationHelper.createChannels(context);         // once at startup
 *   NotificationHelper.showFraudAlert(context, ...);    // after AI says danger
 *   NotificationHelper.showSafeAlert(context, ...);     // after AI says safe
 *   NotificationHelper.showUrlAlert(context, ...);      // bad link found in SMS
 */
public class NotificationHelper {

    // ── Channel IDs ────────────────────────────────────────────────────────
    public static final String CHANNEL_FRAUD = "fraudshield_fraud";
    public static final String CHANNEL_SAFE  = "fraudshield_safe";

    // ── Notification IDs (each must be unique) ─────────────────────────────
    private static int notifCounter = 2000;

    private static int nextId() {
        return notifCounter++;
    }

    // ── Create channels (call once in Application.onCreate) ────────────────

    public static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        // FRAUD channel — highest importance, red LED, vibrate
        NotificationChannel fraudChannel = new NotificationChannel(
                CHANNEL_FRAUD,
                "Fraud Alerts",
                NotificationManager.IMPORTANCE_HIGH
        );
        fraudChannel.setDescription("Real-time fraud and phishing alerts");
        fraudChannel.enableLights(true);
        fraudChannel.setLightColor(Color.RED);
        fraudChannel.enableVibration(true);
        fraudChannel.setVibrationPattern(new long[]{0, 300, 200, 300});
        fraudChannel.setBypassDnd(true);
        fraudChannel.setShowBadge(true);
        nm.createNotificationChannel(fraudChannel);

        // SAFE channel — normal importance
        NotificationChannel safeChannel = new NotificationChannel(
                CHANNEL_SAFE,
                "Safe Messages",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        safeChannel.setDescription("Messages confirmed safe by AI");
        safeChannel.setShowBadge(false);
        nm.createNotificationChannel(safeChannel);
    }

    // ── Show ⚠️ Fraud Alert ────────────────────────────────────────────────

    /**
     * Shows a high-priority fraud notification on the status bar.
     * Appears even when the phone is locked.
     *
     * @param sender    SMS sender (e.g. "HBL-BANK")
     * @param summary   One-line AI summary
     * @param riskScore 0–100 risk score from AI
     * @param reasons   First reason from AI (shown in expanded view)
     */
    public static void showFraudAlert(Context context,
                                      String sender,
                                      String summary,
                                      int riskScore,
                                      String reasons) {
        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pi = PendingIntent.getActivity(
                context, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_FRAUD)
                .setSmallIcon(R.drawable.ic_shield)          // add your shield icon
                .setContentTitle("⚠️ Fraud Alert — " + sender)
                .setContentText(summary)
                .setSubText("Risk Score: " + riskScore + "/100")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(summary + "\n\n🔍 " + reasons))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(Color.RED)
                .setAutoCancel(true)
                .setContentIntent(pi);

        try {
            NotificationManagerCompat.from(context).notify(nextId(), builder.build());
        } catch (SecurityException e) {
            // POST_NOTIFICATIONS permission not granted — ask user in MainActivity
        }
    }

    // ── Show ✅ Safe Message ───────────────────────────────────────────────

    public static void showSafeAlert(Context context,
                                     String sender,
                                     String summary,
                                     int riskScore) {
        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                context, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_SAFE)
                .setSmallIcon(R.drawable.ic_shield)
                .setContentTitle("✅ Safe Message — " + sender)
                .setContentText(summary)
                .setSubText("Risk Score: " + riskScore + "/100")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(Color.GREEN)
                .setAutoCancel(true)
                .setContentIntent(pi);

        try {
            NotificationManagerCompat.from(context).notify(nextId(), builder.build());
        } catch (SecurityException e) {
            // permission not granted
        }
    }

    // ── Show ⚠️ Dangerous URL Alert ───────────────────────────────────────

    public static void showUrlAlert(Context context,
                                    String url,
                                    int riskScore) {
        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                context, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String shortUrl = url.length() > 50 ? url.substring(0, 50) + "…" : url;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_FRAUD)
                .setSmallIcon(R.drawable.ic_shield)
                .setContentTitle("⚠️ Dangerous Link in SMS")
                .setContentText(shortUrl)
                .setSubText("Risk Score: " + riskScore + "/100 — Do NOT open this link")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Dangerous link detected:\n" + url +
                                "\n\nRisk Score: " + riskScore + "/100\nDo NOT tap this link."))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setColor(Color.RED)
                .setAutoCancel(true)
                .setContentIntent(pi);

        try {
            NotificationManagerCompat.from(context).notify(nextId(), builder.build());
        } catch (SecurityException e) {
            // permission not granted
        }
    }
}
