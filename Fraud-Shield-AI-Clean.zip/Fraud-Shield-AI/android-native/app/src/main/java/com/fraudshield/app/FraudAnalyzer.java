package com.fraudshield.app;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * FraudAnalyzer — sends SMS text or URL to the live AI API and returns a verdict.
 *
 * The AI is running on your Replit server at:
 *   POST https://f10afdbb-2ebb-446e-81b8-2224c45116d2-00-3mje5qjflprbg.riker.replit.dev/api/ai/analyze
 *
 * Request  JSON: { "kind": "sms"|"link", "content": "...", "locale": "en" }
 * Response JSON: { "verdict": "safe"|"suspicious"|"danger",
 *                  "riskScore": 0–100, "summary": "...",
 *                  "reasons": [...], "recommendation": "..." }
 *
 * All methods are SYNCHRONOUS — call them from a background thread (WorkManager).
 */
public class FraudAnalyzer {

    private static final String TAG = "FraudShield_AI";

    // ── Your live AI API endpoint ──────────────────────────────────────────
    // This is already running — no setup needed.
    private static final String API_URL =
            "https://f10afdbb-2ebb-446e-81b8-2224c45116d2-00-3mje5qjflprbg.riker.replit.dev/api/ai/analyze";

    private static final MediaType JSON_TYPE =
            MediaType.parse("application/json; charset=utf-8");

    // URL extraction regex — finds http/https links and bare domains.
    private static final Pattern URL_PATTERN = Pattern.compile(
            "(?:https?://)[^\\s,;'\"<>()\\[\\]]+|" +
            "(?:www\\.)[a-zA-Z0-9\\-]+\\.[a-zA-Z]{2,}(?:/[^\\s]*)?|" +
            "(?:[a-zA-Z0-9\\-]+\\.(?:tk|ml|ga|cf|gq|xyz|top|click))(?:/[^\\s]*)?",
            Pattern.CASE_INSENSITIVE
    );

    // Suspicious free-hosting TLDs commonly used in phishing.
    private static final String[] SUSPICIOUS_TLDS =
            {".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".click"};

    // Reusable HTTP client — keep-alive, timeouts configured.
    private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build();

    // ── Result model ──────────────────────────────────────────────────────

    public static class AiResult {
        public final String verdict;          // "safe" | "suspicious" | "danger"
        public final int riskScore;           // 0–100
        public final String summary;          // one sentence
        public final List<String> reasons;    // specific signals
        public final String recommendation;   // what user should do

        public AiResult(String verdict, int riskScore, String summary,
                        List<String> reasons, String recommendation) {
            this.verdict       = verdict;
            this.riskScore     = riskScore;
            this.summary       = summary;
            this.reasons       = reasons;
            this.recommendation = recommendation;
        }

        /** Returns true for danger or suspicious verdicts. */
        public boolean isThreat() {
            return "danger".equals(verdict) || "suspicious".equals(verdict);
        }

        /** First reason string, or empty if none. */
        public String firstReason() {
            return reasons != null && !reasons.isEmpty() ? reasons.get(0) : "";
        }
    }

    // ── Public API ────────────────────────────────────────────────────────

    /**
     * Analyze an SMS message with the live AI.
     * @param sender  e.g. "HBL-BANK" or "+92300..."
     * @param body    Full SMS text
     * @return AiResult, or null if the network call failed
     */
    public static AiResult analyzeSms(String sender, String body) {
        String content = "From: " + sender + "\n" + body;
        return callApi("sms", content);
    }

    /**
     * Analyze a URL with the live AI phishing detector.
     * @param url  Full or partial URL found in an SMS
     * @return AiResult, or null if the network call failed
     */
    public static AiResult analyzeUrl(String url) {
        return callApi("link", url);
    }

    /**
     * Extract all URLs from SMS body text.
     * Returns an empty list if no URLs are found.
     */
    public static List<String> extractUrls(String smsBody) {
        List<String> found = new ArrayList<>();
        Matcher m = URL_PATTERN.matcher(smsBody);
        while (m.find()) {
            found.add(m.group());
        }
        return found;
    }

    /**
     * Quick local check: is this URL suspicious based on its TLD?
     * Faster than a full AI call — use as a pre-filter.
     */
    public static boolean isSuspiciousByTld(String url) {
        String lower = url.toLowerCase();
        for (String tld : SUSPICIOUS_TLDS) {
            if (lower.contains(tld)) return true;
        }
        // Raw IP address (e.g. http://192.168.1.1/bank)
        return lower.matches(".*\\b\\d{1,3}(\\.\\d{1,3}){3}\\b.*");
    }

    // ── Internal: HTTP call ───────────────────────────────────────────────

    private static AiResult callApi(String kind, String content) {
        try {
            // Build JSON request body.
            JSONObject payload = new JSONObject();
            payload.put("kind", kind);
            payload.put("content", content);
            payload.put("locale", "en");

            RequestBody body = RequestBody.create(payload.toString(), JSON_TYPE);

            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(body)
                    .addHeader("Content-Type", "application/json")
                    .build();

            // Execute synchronously — must be called from a background thread.
            try (Response response = HTTP_CLIENT.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e(TAG, "API returned error: HTTP " + response.code());
                    return null;
                }
                String responseJson = response.body().string();
                Log.d(TAG, "AI response: " + responseJson);
                return parseResult(responseJson);
            }

        } catch (IOException e) {
            Log.e(TAG, "Network error calling AI: " + e.getMessage());
            return null;
        } catch (JSONException e) {
            Log.e(TAG, "JSON parse error: " + e.getMessage());
            return null;
        }
    }

    private static AiResult parseResult(String json) throws JSONException {
        JSONObject obj = new JSONObject(json);

        String verdict        = obj.optString("verdict", "suspicious");
        int riskScore         = obj.optInt("riskScore", 50);
        String summary        = obj.optString("summary", "Could not fully analyze.");
        String recommendation = obj.optString("recommendation", "Proceed with caution.");

        List<String> reasons = new ArrayList<>();
        JSONArray arr = obj.optJSONArray("reasons");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                reasons.add(arr.getString(i));
            }
        }

        return new AiResult(verdict, riskScore, summary, reasons, recommendation);
    }
}
