# 🛡️ FraudShield AI

**FraudShield AI** is an AI-powered fraud detection mobile app that protects banking users from financial scams, phishing SMS messages, and suspicious links. Built with **React Native (Expo)**, it is backed by an **Express API server** that performs real-time fraud analysis using OpenAI.

---

## ✨ Features

- 🔍 **Transaction Analysis** — Automatically scans each transaction and assigns a risk score based on suspicious signals (large amounts, unknown devices, foreign locations)
- 📩 **SMS Scanner** — Analyzes incoming messages for phishing keywords and embedded suspicious links
- 🔗 **Link Checker** — Checks URLs in real time, detecting suspicious TLDs, URL shorteners, phishing keywords, and raw IP addresses
- 🤖 **AI-Powered Analysis** — Uses OpenAI GPT to perform deep contextual analysis of SMS messages and links, returning verdicts in both English and Urdu
- 🔐 **Secure Vault** — Biometric-protected (Face ID / Fingerprint) storage for cards, passwords, and sensitive notes
- 📊 **Security Score** — Displays the user's overall security health as a 0–100 score
- 🔔 **Background Notifications** — Sends alerts when suspicious activity is detected in the background

---

## 🏗️ Project Structure

```
Fraud-Shield-AI/
├── artifacts/
│   ├── fraudshield/          # React Native (Expo) mobile app
│   │   ├── lib/
│   │   │   ├── data/         # API clients, storage, biometric, notifications
│   │   │   └── domain/       # Pure fraud detection logic (analyzers, URL extractor)
│   │   ├── constants/        # Theme colors
│   │   └── hooks/            # Custom React hooks
│   ├── api-server/           # Express 5 backend
│   │   └── src/
│   │       ├── routes/       # API routes (health, AI analyze)
│   │       └── lib/          # Logger, OpenAI client
│   └── mockup-sandbox/       # UI component preview sandbox
├── lib/
│   ├── api-spec/             # OpenAPI spec + Orval codegen config
│   ├── api-zod/              # Auto-generated Zod validation schemas
│   ├── api-client-react/     # Auto-generated React Query API hooks
│   └── db/                   # PostgreSQL schema (Drizzle ORM)
└── scripts/                  # Helper scripts
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Mobile App | React Native + Expo (SDK 54) |
| Navigation | Expo Router (file-based) |
| Backend | Express 5 + Node.js 24 |
| AI | OpenAI GPT (gpt-5-mini) |
| Database | PostgreSQL + Drizzle ORM |
| Validation | Zod v4 + drizzle-zod |
| API Codegen | Orval (OpenAPI → React Query hooks) |
| Auth | expo-local-authentication (Face ID / Fingerprint) |
| Storage | expo-secure-store + AsyncStorage |
| Package Manager | pnpm workspaces (monorepo) |
| Language | TypeScript 5.9 |

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** v24+
- **pnpm** v9+
- **PostgreSQL** database
- **OpenAI API Key**

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd Fraud-Shield-AI

# Install dependencies
pnpm install
```

### Environment Variables

Create a `.env` file inside `artifacts/api-server/`:

```env
OPENAI_API_KEY=your_openai_api_key_here
DATABASE_URL=postgresql://user:password@localhost:5432/fraudshield
PORT=3000
```

### Database Setup

```bash
# Push the schema to your database (development only)
pnpm --filter @workspace/db run push
```

### Development

```bash
# Start the API server
pnpm --filter @workspace/api-server run dev

# Start the mobile app (in a separate terminal)
pnpm --filter @workspace/fraudshield run dev
```

---

## 📋 Available Commands

```bash
# Run typecheck across all packages
pnpm run typecheck

# Build all packages
pnpm run build

# Regenerate API hooks and Zod schemas from the OpenAPI spec
pnpm --filter @workspace/api-spec run codegen

# Push DB schema changes (dev only)
pnpm --filter @workspace/db run push

# Run the API server locally
pnpm --filter @workspace/api-server run dev
```

---

## 🔌 API Endpoints

### `POST /api/ai/analyze`

Performs AI-powered fraud analysis on an SMS message or URL.

**Request Body:**
```json
{
  "kind": "sms",        // "sms" or "link"
  "content": "...",     // Text to analyze (max 2000 characters)
  "locale": "en"        // "en" (English) or "ur" (Urdu)
}
```

**Response:**
```json
{
  "verdict": "danger",
  "riskScore": 85,
  "summary": "This message contains phishing indicators.",
  "reasons": ["Requests OTP", "Contains suspicious link"],
  "recommendation": "Do not click any links or share your OTP."
}
```

### `GET /api/health`

Server health check endpoint.

---

## 🧠 Fraud Detection Logic

The app uses two layers of fraud detection:

### 1. Rule-Based (Offline, Instant)
- **Transactions:** Checks amount thresholds, unknown devices, untrusted locations, and high-risk categories (Wire Transfer, Crypto)
- **SMS:** Scans for phishing keywords (`otp`, `verify`, `account blocked`, `lucky draw`, etc.) and embedded URLs
- **Links:** Detects suspicious TLDs (`.tk`, `.ml`, `.xyz`), URL shorteners, raw IP addresses, and phishing hint words in the domain

### 2. AI-Powered (via OpenAI)
- Deep contextual analysis for ambiguous or complex cases
- Supports English and Urdu responses
- Returns a structured JSON verdict with specific reasons and an actionable recommendation

---

## 🌍 Localization

The app supports both **English** and **Urdu**. AI-generated analysis also responds in the user's chosen language.

---

## 🔒 Security Features

- Biometric authentication (Face ID / Fingerprint / Device PIN)
- Encrypted secure storage for vault items
- Background fraud monitoring with push notifications
- Web fallback for browser-based demo (no biometric required)

---

## 📱 Android Permissions

```
RECEIVE_SMS, READ_SMS        — For SMS scanning
INTERNET                     — For API calls
POST_NOTIFICATIONS           — For fraud alerts
FOREGROUND_SERVICE           — For background monitoring
RECEIVE_BOOT_COMPLETED       — For auto-start on device boot
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

MIT License — see the [LICENSE](LICENSE) file for details.
